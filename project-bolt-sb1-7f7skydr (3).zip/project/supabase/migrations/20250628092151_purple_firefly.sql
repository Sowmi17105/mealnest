/*
  # Separate Database Structure for Customers and Homemakers

  1. New Tables
    - `customer_accounts` - Dedicated customer profiles with subscription preferences
    - `homemaker_accounts` - Dedicated homemaker profiles with business details
    - `customer_preferences` - Customer dietary preferences and delivery settings
    - `homemaker_business_details` - Extended business information for homemakers
    - `customer_addresses` - Multiple delivery addresses for customers
    - `homemaker_service_areas` - Service areas for homemakers

  2. Security
    - Enable RLS on all new tables
    - Add policies for users to manage their own data
    - Separate authentication flows for customers and homemakers

  3. Features
    - Instagram-like separate account types
    - Enhanced profile management
    - Better data organization
*/

-- Customer Accounts Table (Like Instagram customer profiles)
CREATE TABLE IF NOT EXISTS customer_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  username text UNIQUE,
  display_name text NOT NULL,
  email text UNIQUE NOT NULL,
  phone text,
  profile_image_url text,
  bio text,
  date_of_birth date,
  gender text CHECK (gender IN ('male', 'female', 'other', 'prefer_not_to_say')),
  is_verified boolean DEFAULT false,
  account_status text DEFAULT 'active' CHECK (account_status IN ('active', 'suspended', 'deactivated')),
  total_orders integer DEFAULT 0,
  total_spent numeric(10,2) DEFAULT 0,
  loyalty_points integer DEFAULT 0,
  preferred_cuisine text[],
  dietary_restrictions text[],
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Homemaker Accounts Table (Like Instagram business profiles)
CREATE TABLE IF NOT EXISTS homemaker_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  username text UNIQUE,
  business_name text NOT NULL,
  display_name text NOT NULL,
  email text UNIQUE NOT NULL,
  phone text NOT NULL,
  profile_image_url text,
  cover_image_url text,
  bio text,
  business_description text NOT NULL,
  specialties text[] DEFAULT '{}',
  cuisine_types text[] DEFAULT '{}',
  experience_years integer DEFAULT 0,
  certifications text[],
  rating numeric(3,2) DEFAULT 0 CHECK (rating >= 0 AND rating <= 5),
  total_reviews integer DEFAULT 0,
  total_orders integer DEFAULT 0,
  is_verified boolean DEFAULT false,
  verification_status text DEFAULT 'pending' CHECK (verification_status IN ('pending', 'verified', 'rejected')),
  is_active boolean DEFAULT true,
  account_status text DEFAULT 'active' CHECK (account_status IN ('active', 'suspended', 'deactivated')),
  business_license text,
  fssai_license text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Customer Addresses Table
CREATE TABLE IF NOT EXISTS customer_addresses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES customer_accounts(id) ON DELETE CASCADE,
  address_type text DEFAULT 'home' CHECK (address_type IN ('home', 'work', 'other')),
  address_line_1 text NOT NULL,
  address_line_2 text,
  city text NOT NULL,
  state text NOT NULL,
  postal_code text NOT NULL,
  landmark text,
  delivery_instructions text,
  is_default boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Homemaker Service Areas Table
CREATE TABLE IF NOT EXISTS homemaker_service_areas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  homemaker_id uuid NOT NULL REFERENCES homemaker_accounts(id) ON DELETE CASCADE,
  area_name text NOT NULL,
  city text NOT NULL,
  state text NOT NULL,
  postal_codes text[],
  delivery_fee numeric(8,2) DEFAULT 0,
  minimum_order_amount numeric(10,2) DEFAULT 0,
  delivery_time_minutes integer DEFAULT 30,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Customer Preferences Table
CREATE TABLE IF NOT EXISTS customer_preferences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES customer_accounts(id) ON DELETE CASCADE,
  preferred_meal_times jsonb DEFAULT '{}',
  spice_level text DEFAULT 'medium' CHECK (spice_level IN ('mild', 'medium', 'spicy', 'extra_spicy')),
  portion_size text DEFAULT 'regular' CHECK (portion_size IN ('small', 'regular', 'large')),
  dietary_preferences text[] DEFAULT '{}',
  allergies text[] DEFAULT '{}',
  favorite_cuisines text[] DEFAULT '{}',
  disliked_ingredients text[] DEFAULT '{}',
  notification_preferences jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Homemaker Business Details Table
CREATE TABLE IF NOT EXISTS homemaker_business_details (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  homemaker_id uuid NOT NULL REFERENCES homemaker_accounts(id) ON DELETE CASCADE,
  kitchen_type text CHECK (kitchen_type IN ('home_kitchen', 'commercial_kitchen', 'cloud_kitchen')),
  kitchen_capacity integer DEFAULT 10,
  operating_hours jsonb DEFAULT '{}',
  operating_days text[] DEFAULT '{}',
  advance_booking_days integer DEFAULT 1,
  cancellation_policy text,
  refund_policy text,
  payment_methods text[] DEFAULT '{}',
  bank_account_details jsonb,
  tax_details jsonb,
  insurance_details jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE customer_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE homemaker_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE customer_addresses ENABLE ROW LEVEL SECURITY;
ALTER TABLE homemaker_service_areas ENABLE ROW LEVEL SECURITY;
ALTER TABLE customer_preferences ENABLE ROW LEVEL SECURITY;
ALTER TABLE homemaker_business_details ENABLE ROW LEVEL SECURITY;

-- Indexes for better performance
CREATE INDEX IF NOT EXISTS idx_customer_accounts_user_id ON customer_accounts(user_id);
CREATE INDEX IF NOT EXISTS idx_customer_accounts_username ON customer_accounts(username);
CREATE INDEX IF NOT EXISTS idx_customer_accounts_email ON customer_accounts(email);

CREATE INDEX IF NOT EXISTS idx_homemaker_accounts_user_id ON homemaker_accounts(user_id);
CREATE INDEX IF NOT EXISTS idx_homemaker_accounts_username ON homemaker_accounts(username);
CREATE INDEX IF NOT EXISTS idx_homemaker_accounts_business_name ON homemaker_accounts(business_name);
CREATE INDEX IF NOT EXISTS idx_homemaker_accounts_rating ON homemaker_accounts(rating DESC);

CREATE INDEX IF NOT EXISTS idx_customer_addresses_customer_id ON customer_addresses(customer_id);
CREATE INDEX IF NOT EXISTS idx_homemaker_service_areas_homemaker_id ON homemaker_service_areas(homemaker_id);
CREATE INDEX IF NOT EXISTS idx_customer_preferences_customer_id ON customer_preferences(customer_id);
CREATE INDEX IF NOT EXISTS idx_homemaker_business_details_homemaker_id ON homemaker_business_details(homemaker_id);

-- RLS Policies for Customer Accounts
CREATE POLICY "Customers can read own account"
  ON customer_accounts FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Customers can update own account"
  ON customer_accounts FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Anyone can read public customer profiles"
  ON customer_accounts FOR SELECT
  TO authenticated
  USING (account_status = 'active');

-- RLS Policies for Homemaker Accounts
CREATE POLICY "Homemakers can read own account"
  ON homemaker_accounts FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Homemakers can update own account"
  ON homemaker_accounts FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Anyone can read active verified homemaker profiles"
  ON homemaker_accounts FOR SELECT
  TO authenticated
  USING (is_active = true AND verification_status = 'verified' AND account_status = 'active');

-- RLS Policies for Customer Addresses
CREATE POLICY "Customers can manage own addresses"
  ON customer_addresses FOR ALL
  TO authenticated
  USING (customer_id IN (
    SELECT id FROM customer_accounts WHERE user_id = auth.uid()
  ));

-- RLS Policies for Homemaker Service Areas
CREATE POLICY "Homemakers can manage own service areas"
  ON homemaker_service_areas FOR ALL
  TO authenticated
  USING (homemaker_id IN (
    SELECT id FROM homemaker_accounts WHERE user_id = auth.uid()
  ));

CREATE POLICY "Anyone can read active service areas"
  ON homemaker_service_areas FOR SELECT
  TO authenticated
  USING (is_active = true);

-- RLS Policies for Customer Preferences
CREATE POLICY "Customers can manage own preferences"
  ON customer_preferences FOR ALL
  TO authenticated
  USING (customer_id IN (
    SELECT id FROM customer_accounts WHERE user_id = auth.uid()
  ));

-- RLS Policies for Homemaker Business Details
CREATE POLICY "Homemakers can manage own business details"
  ON homemaker_business_details FOR ALL
  TO authenticated
  USING (homemaker_id IN (
    SELECT id FROM homemaker_accounts WHERE user_id = auth.uid()
  ));

-- Triggers for updated_at
CREATE TRIGGER update_customer_accounts_updated_at
  BEFORE UPDATE ON customer_accounts
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_homemaker_accounts_updated_at
  BEFORE UPDATE ON homemaker_accounts
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_customer_addresses_updated_at
  BEFORE UPDATE ON customer_addresses
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_homemaker_service_areas_updated_at
  BEFORE UPDATE ON homemaker_service_areas
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_customer_preferences_updated_at
  BEFORE UPDATE ON customer_preferences
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_homemaker_business_details_updated_at
  BEFORE UPDATE ON homemaker_business_details
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();