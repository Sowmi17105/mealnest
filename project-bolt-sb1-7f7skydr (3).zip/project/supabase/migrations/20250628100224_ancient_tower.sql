/*
  # Fix RLS Policies for User Registration

  1. Security Updates
    - Add INSERT policy for profiles table to allow user registration
    - Add INSERT policies for customer_accounts and homemaker_accounts
    - Ensure users can create their own profiles during registration

  2. Policy Changes
    - Allow authenticated users to insert their own profile
    - Allow users to create customer/homemaker accounts linked to their profile
*/

-- Drop existing policies that might be blocking registration
DROP POLICY IF EXISTS "Users can read own profile" ON profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON profiles;

-- Recreate policies with INSERT permission for registration
CREATE POLICY "Users can read own profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

-- Add INSERT policy for profiles (crucial for registration)
CREATE POLICY "Users can create own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Add INSERT policies for customer accounts
DROP POLICY IF EXISTS "Customers can create own account" ON customer_accounts;
CREATE POLICY "Customers can create own account"
  ON customer_accounts FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

-- Add INSERT policies for homemaker accounts  
DROP POLICY IF EXISTS "Homemakers can create own account" ON homemaker_accounts;
CREATE POLICY "Homemakers can create own account"
  ON homemaker_accounts FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

-- Add INSERT policy for homemaker profiles (legacy compatibility)
DROP POLICY IF EXISTS "Homemakers can create own profile" ON homemaker_profiles;
CREATE POLICY "Homemakers can create own profile"
  ON homemaker_profiles FOR INSERT
  TO authenticated
  WITH CHECK (user_id IN (
    SELECT id FROM profiles WHERE id = auth.uid()
  ));