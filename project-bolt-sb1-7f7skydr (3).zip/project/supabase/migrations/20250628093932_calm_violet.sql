-- =====================================================
-- MEALNEST PLATFORM - COMPLETE DATABASE SCHEMA
-- =====================================================

-- First, create custom types (enums)
CREATE TYPE user_type AS ENUM ('customer', 'homemaker');
CREATE TYPE verification_status AS ENUM ('pending', 'verified', 'rejected');
CREATE TYPE meal_type AS ENUM ('breakfast', 'lunch', 'dinner', 'full_day');
CREATE TYPE subscription_status AS ENUM ('active', 'paused', 'cancelled');
CREATE TYPE subscription_type AS ENUM ('monthly', 'quarterly', 'yearly');

-- Create function for updating timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- =====================================================
-- 1. PROFILES TABLE (Basic user information)
-- =====================================================
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text UNIQUE NOT NULL,
  full_name text NOT NULL,
  user_type user_type NOT NULL,
  phone text,
  address text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can read own profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

-- Trigger for updated_at
CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- 2. CUSTOMER ACCOUNTS TABLE (Instagram-like customer profiles)
-- =====================================================
CREATE TABLE IF NOT EXISTS customer_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  username text UNIQUE,
  display_name text NOT NULL,
  email text UNIQUE NOT NULL,
  phone text,
  profile_image_url text,
  bio text,
  date_of_birth date,
  gender text CHECK (gender IN ('male', 'female', 'other', 'prefer_not_to_say')),
  is_verified boolean DEFAULT false,
  account_status text DEFAULT 'active' CHECK (account_status IN ('active', 'suspended', 'deactivated')),
  total_orders integer DEFAULT 0,
  total_spent numeric(10,2) DEFAULT 0,
  loyalty_points integer DEFAULT 0,
  preferred_cuisine text[],
  dietary_restrictions text[],
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE customer_accounts ENABLE ROW LEVEL SECURITY;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_customer_accounts_user_id ON customer_accounts(user_id);
CREATE INDEX IF NOT EXISTS idx_customer_accounts_username ON customer_accounts(username);
CREATE INDEX IF NOT EXISTS idx_customer_accounts_email ON customer_accounts(email);

-- RLS Policies
CREATE POLICY "Customers can read own account"
  ON customer_accounts FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Customers can update own account"
  ON customer_accounts FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Anyone can read public customer profiles"
  ON customer_accounts FOR SELECT
  TO authenticated
  USING (account_status = 'active');

-- Trigger
CREATE TRIGGER update_customer_accounts_updated_at
  BEFORE UPDATE ON customer_accounts
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- 3. HOMEMAKER ACCOUNTS TABLE (Instagram-like business profiles)
-- =====================================================
CREATE TABLE IF NOT EXISTS homemaker_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  username text UNIQUE,
  business_name text NOT NULL,
  display_name text NOT NULL,
  email text UNIQUE NOT NULL,
  phone text NOT NULL,
  profile_image_url text,
  cover_image_url text,
  bio text,
  business_description text NOT NULL,
  specialties text[] DEFAULT '{}',
  cuisine_types text[] DEFAULT '{}',
  experience_years integer DEFAULT 0,
  certifications text[],
  rating numeric(3,2) DEFAULT 0 CHECK (rating >= 0 AND rating <= 5),
  total_reviews integer DEFAULT 0,
  total_orders integer DEFAULT 0,
  is_verified boolean DEFAULT false,
  verification_status text DEFAULT 'pending' CHECK (verification_status IN ('pending', 'verified', 'rejected')),
  is_active boolean DEFAULT true,
  account_status text DEFAULT 'active' CHECK (account_status IN ('active', 'suspended', 'deactivated')),
  business_license text,
  fssai_license text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE homemaker_accounts ENABLE ROW LEVEL SECURITY;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_homemaker_accounts_user_id ON homemaker_accounts(user_id);
CREATE INDEX IF NOT EXISTS idx_homemaker_accounts_username ON homemaker_accounts(username);
CREATE INDEX IF NOT EXISTS idx_homemaker_accounts_business_name ON homemaker_accounts(business_name);
CREATE INDEX IF NOT EXISTS idx_homemaker_accounts_rating ON homemaker_accounts(rating DESC);

-- RLS Policies
CREATE POLICY "Homemakers can read own account"
  ON homemaker_accounts FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Homemakers can update own account"
  ON homemaker_accounts FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Anyone can read active verified homemaker profiles"
  ON homemaker_accounts FOR SELECT
  TO authenticated
  USING (is_active = true AND verification_status = 'verified' AND account_status = 'active');

-- Trigger
CREATE TRIGGER update_homemaker_accounts_updated_at
  BEFORE UPDATE ON homemaker_accounts
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- 4. HOMEMAKER PROFILES TABLE (Legacy compatibility)
-- =====================================================
CREATE TABLE IF NOT EXISTS homemaker_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  business_name text NOT NULL,
  description text NOT NULL,
  specialties text[] DEFAULT '{}',
  rating numeric(3,2) DEFAULT 0 CHECK (rating >= 0 AND rating <= 5),
  total_reviews integer DEFAULT 0,
  is_active boolean DEFAULT true,
  verification_status verification_status DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE homemaker_profiles ENABLE ROW LEVEL SECURITY;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_homemaker_profiles_user_id ON homemaker_profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_homemaker_profiles_rating ON homemaker_profiles(rating DESC);

-- RLS Policies
CREATE POLICY "Anyone can read active homemaker profiles"
  ON homemaker_profiles FOR SELECT
  TO authenticated
  USING (is_active = true AND verification_status = 'verified');

CREATE POLICY "Homemakers can manage own profile"
  ON homemaker_profiles FOR ALL
  TO authenticated
  USING (user_id = auth.uid());

-- Trigger
CREATE TRIGGER update_homemaker_profiles_updated_at
  BEFORE UPDATE ON homemaker_profiles
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- 5. MEAL PLANS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS meal_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  homemaker_id uuid NOT NULL REFERENCES homemaker_profiles(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text NOT NULL,
  price_per_day numeric(10,2) NOT NULL CHECK (price_per_day > 0),
  meal_type meal_type NOT NULL,
  is_available boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE meal_plans ENABLE ROW LEVEL SECURITY;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_meal_plans_homemaker_id ON meal_plans(homemaker_id);
CREATE INDEX IF NOT EXISTS idx_meal_plans_meal_type ON meal_plans(meal_type);

-- RLS Policies
CREATE POLICY "Anyone can read available meal plans"
  ON meal_plans FOR SELECT
  TO authenticated
  USING (is_available = true);

CREATE POLICY "Homemakers can manage own meal plans"
  ON meal_plans FOR ALL
  TO authenticated
  USING (homemaker_id IN (
    SELECT id FROM homemaker_profiles WHERE user_id = auth.uid()
  ));

-- Trigger
CREATE TRIGGER update_meal_plans_updated_at
  BEFORE UPDATE ON meal_plans
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- 6. SUBSCRIPTIONS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  meal_plan_id uuid NOT NULL REFERENCES meal_plans(id) ON DELETE CASCADE,
  start_date date NOT NULL,
  end_date date NOT NULL,
  status subscription_status DEFAULT 'active',
  subscription_type subscription_type NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_subscriptions_customer_id ON subscriptions(customer_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_meal_plan_id ON subscriptions(meal_plan_id);

-- RLS Policies
CREATE POLICY "Customers can read own subscriptions"
  ON subscriptions FOR SELECT
  TO authenticated
  USING (customer_id = auth.uid());

CREATE POLICY "Customers can create subscriptions"
  ON subscriptions FOR INSERT
  TO authenticated
  WITH CHECK (customer_id = auth.uid());

CREATE POLICY "Customers can update own subscriptions"
  ON subscriptions FOR UPDATE
  TO authenticated
  USING (customer_id = auth.uid());

-- Trigger
CREATE TRIGGER update_subscriptions_updated_at
  BEFORE UPDATE ON subscriptions
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- 7. REVIEWS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  homemaker_id uuid NOT NULL REFERENCES homemaker_profiles(id) ON DELETE CASCADE,
  subscription_id uuid NOT NULL REFERENCES subscriptions(id) ON DELETE CASCADE,
  rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_reviews_customer_id ON reviews(customer_id);
CREATE INDEX IF NOT EXISTS idx_reviews_homemaker_id ON reviews(homemaker_id);

-- RLS Policies
CREATE POLICY "Anyone can read reviews"
  ON reviews FOR SELECT
  TO authenticated;

CREATE POLICY "Customers can create reviews for their subscriptions"
  ON reviews FOR INSERT
  TO authenticated
  WITH CHECK (
    customer_id = auth.uid() AND 
    subscription_id IN (
      SELECT id FROM subscriptions WHERE customer_id = auth.uid()
    )
  );

CREATE POLICY "Customers can update own reviews"
  ON reviews FOR UPDATE
  TO authenticated
  USING (customer_id = auth.uid());

-- Function to update homemaker rating
CREATE OR REPLACE FUNCTION update_homemaker_rating()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE homemaker_profiles 
  SET 
    rating = (
      SELECT AVG(rating)::numeric(3,2) 
      FROM reviews 
      WHERE homemaker_id = NEW.homemaker_id
    ),
    total_reviews = (
      SELECT COUNT(*) 
      FROM reviews 
      WHERE homemaker_id = NEW.homemaker_id
    )
  WHERE id = NEW.homemaker_id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to update homemaker rating when review is added/updated
CREATE TRIGGER update_homemaker_rating_trigger
  AFTER INSERT OR UPDATE ON reviews
  FOR EACH ROW
  EXECUTE FUNCTION update_homemaker_rating();

-- Trigger for updated_at
CREATE TRIGGER update_reviews_updated_at
  BEFORE UPDATE ON reviews
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- 8. DAILY REPORTS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS daily_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  homemaker_id uuid NOT NULL REFERENCES homemaker_profiles(id) ON DELETE CASCADE,
  report_date date NOT NULL,
  full_day_recipes text[] DEFAULT '{}',
  instant_recipes text[] DEFAULT '{}',
  breakfast_specialties text[] DEFAULT '{}',
  lunch_specialties text[] DEFAULT '{}',
  dinner_specialties text[] DEFAULT '{}',
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(homemaker_id, report_date)
);

-- Enable RLS
ALTER TABLE daily_reports ENABLE ROW LEVEL SECURITY;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_daily_reports_homemaker_date ON daily_reports(homemaker_id, report_date);
CREATE INDEX IF NOT EXISTS idx_daily_reports_date_active ON daily_reports(report_date, is_active);

-- RLS Policies
CREATE POLICY "Anyone can read active daily reports"
  ON daily_reports FOR SELECT
  TO authenticated
  USING (is_active = true);

CREATE POLICY "Homemakers can manage own daily reports"
  ON daily_reports FOR ALL
  TO authenticated
  USING (homemaker_id IN (
    SELECT id FROM homemaker_profiles WHERE user_id = auth.uid()
  ))
  WITH CHECK (homemaker_id IN (
    SELECT id FROM homemaker_profiles WHERE user_id = auth.uid()
  ));

-- Trigger
CREATE TRIGGER update_daily_reports_updated_at
  BEFORE UPDATE ON daily_reports
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- 9. CUSTOMER ADDRESSES TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS customer_addresses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES customer_accounts(id) ON DELETE CASCADE,
  address_type text DEFAULT 'home' CHECK (address_type IN ('home', 'work', 'other')),
  address_line_1 text NOT NULL,
  address_line_2 text,
  city text NOT NULL,
  state text NOT NULL,
  postal_code text NOT NULL,
  landmark text,
  delivery_instructions text,
  is_default boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE customer_addresses ENABLE ROW LEVEL SECURITY;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_customer_addresses_customer_id ON customer_addresses(customer_id);

-- RLS Policies
CREATE POLICY "Customers can manage own addresses"
  ON customer_addresses FOR ALL
  TO authenticated
  USING (customer_id IN (
    SELECT id FROM customer_accounts WHERE user_id = auth.uid()
  ));

-- Trigger
CREATE TRIGGER update_customer_addresses_updated_at
  BEFORE UPDATE ON customer_addresses
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- 10. HOMEMAKER SERVICE AREAS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS homemaker_service_areas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  homemaker_id uuid NOT NULL REFERENCES homemaker_accounts(id) ON DELETE CASCADE,
  area_name text NOT NULL,
  city text NOT NULL,
  state text NOT NULL,
  postal_codes text[],
  delivery_fee numeric(8,2) DEFAULT 0,
  minimum_order_amount numeric(10,2) DEFAULT 0,
  delivery_time_minutes integer DEFAULT 30,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE homemaker_service_areas ENABLE ROW LEVEL SECURITY;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_homemaker_service_areas_homemaker_id ON homemaker_service_areas(homemaker_id);

-- RLS Policies
CREATE POLICY "Anyone can read active service areas"
  ON homemaker_service_areas FOR SELECT
  TO authenticated
  USING (is_active = true);

CREATE POLICY "Homemakers can manage own service areas"
  ON homemaker_service_areas FOR ALL
  TO authenticated
  USING (homemaker_id IN (
    SELECT id FROM homemaker_accounts WHERE user_id = auth.uid()
  ));

-- Trigger
CREATE TRIGGER update_homemaker_service_areas_updated_at
  BEFORE UPDATE ON homemaker_service_areas
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- 11. CUSTOMER PREFERENCES TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS customer_preferences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES customer_accounts(id) ON DELETE CASCADE,
  preferred_meal_times jsonb DEFAULT '{}',
  spice_level text DEFAULT 'medium' CHECK (spice_level IN ('mild', 'medium', 'spicy', 'extra_spicy')),
  portion_size text DEFAULT 'regular' CHECK (portion_size IN ('small', 'regular', 'large')),
  dietary_preferences text[] DEFAULT '{}',
  allergies text[] DEFAULT '{}',
  favorite_cuisines text[] DEFAULT '{}',
  disliked_ingredients text[] DEFAULT '{}',
  notification_preferences jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE customer_preferences ENABLE ROW LEVEL SECURITY;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_customer_preferences_customer_id ON customer_preferences(customer_id);

-- RLS Policies
CREATE POLICY "Customers can manage own preferences"
  ON customer_preferences FOR ALL
  TO authenticated
  USING (customer_id IN (
    SELECT id FROM customer_accounts WHERE user_id = auth.uid()
  ));

-- Trigger
CREATE TRIGGER update_customer_preferences_updated_at
  BEFORE UPDATE ON customer_preferences
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- 12. HOMEMAKER BUSINESS DETAILS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS homemaker_business_details (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  homemaker_id uuid NOT NULL REFERENCES homemaker_accounts(id) ON DELETE CASCADE,
  kitchen_type text CHECK (kitchen_type IN ('home_kitchen', 'commercial_kitchen', 'cloud_kitchen')),
  kitchen_capacity integer DEFAULT 10,
  operating_hours jsonb DEFAULT '{}',
  operating_days text[] DEFAULT '{}',
  advance_booking_days integer DEFAULT 1,
  cancellation_policy text,
  refund_policy text,
  payment_methods text[] DEFAULT '{}',
  bank_account_details jsonb,
  tax_details jsonb,
  insurance_details jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE homemaker_business_details ENABLE ROW LEVEL SECURITY;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_homemaker_business_details_homemaker_id ON homemaker_business_details(homemaker_id);

-- RLS Policies
CREATE POLICY "Homemakers can manage own business details"
  ON homemaker_business_details FOR ALL
  TO authenticated
  USING (homemaker_id IN (
    SELECT id FROM homemaker_accounts WHERE user_id = auth.uid()
  ));

-- Trigger
CREATE TRIGGER update_homemaker_business_details_updated_at
  BEFORE UPDATE ON homemaker_business_details
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- SAMPLE DATA (Optional - for testing)
-- =====================================================

-- Note: You can uncomment and modify these INSERT statements to add sample data

/*
-- Sample customer account
INSERT INTO customer_accounts (
  user_id, display_name, email, bio, preferred_cuisine, dietary_restrictions
) VALUES (
  'sample-user-id-1',
  'John Doe',
  'john@example.com',
  'Food lover from Bangalore',
  ARRAY['North Indian', 'South Indian'],
  ARRAY['Vegetarian']
);

-- Sample homemaker account
INSERT INTO homemaker_accounts (
  user_id, business_name, display_name, email, phone, business_description, specialties
) VALUES (
  'sample-user-id-2',
  'Amma\'s Kitchen',
  'Priya Sharma',
  'priya@example.com',
  '+91-9876543210',
  'Traditional home-style cooking with love',
  ARRAY['South Indian', 'North Indian', 'Snacks']
);
*/

-- =====================================================
-- END OF SCHEMA
-- =====================================================