-- =====================================================
-- MEALNEST PLATFORM - COMPLETE DATABASE SCHEMA
-- =====================================================

-- First, create custom types (enums)
CREATE TYPE user_type AS ENUM ('customer', 'homemaker');
CREATE TYPE verification_status AS ENUM ('pending', 'verified', 'rejected');
CREATE TYPE meal_type AS ENUM ('breakfast', 'lunch', 'dinner', 'full_day');
CREATE TYPE subscription_status AS ENUM ('active', 'paused', 'cancelled');
CREATE TYPE subscription_type AS ENUM ('monthly', 'quarterly', 'yearly');

-- Create function for updating timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create function for updating user timestamps
CREATE OR REPLACE FUNCTION update_user_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Function to update homemaker rating
CREATE OR REPLACE FUNCTION update_homemaker_rating()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE homemaker_profiles 
  SET 
    rating = (
      SELECT AVG(rating)::numeric(3,2) 
      FROM reviews 
      WHERE homemaker_id = NEW.homemaker_id
    ),
    total_reviews = (
      SELECT COUNT(*) 
      FROM reviews 
      WHERE homemaker_id = NEW.homemaker_id
    )
  WHERE id = NEW.homemaker_id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- =====================================================
-- 1. PROFILES TABLE (Basic user information)
-- =====================================================
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text UNIQUE NOT NULL,
  full_name text NOT NULL,
  user_type user_type NOT NULL,
  phone text,
  address text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can read own profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can create own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Trigger for updated_at
CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- 2. CUSTOMER ACCOUNTS TABLE (Instagram-like customer profiles)
-- =====================================================
CREATE TABLE IF NOT EXISTS customer_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  username text UNIQUE,
  display_name text NOT NULL,
  email text UNIQUE NOT NULL,
  phone text,
  profile_image_url text,
  bio text,
  date_of_birth date,
  gender text CHECK (gender IN ('male', 'female', 'other', 'prefer_not_to_say')),
  is_verified boolean DEFAULT false,
  account_status text DEFAULT 'active' CHECK (account_status IN ('active', 'suspended', 'deactivated')),
  total_orders integer DEFAULT 0,
  total_spent numeric(10,2) DEFAULT 0,
  loyalty_points integer DEFAULT 0,
  preferred_cuisine text[],
  dietary_restrictions text[],
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE customer_accounts ENABLE ROW LEVEL SECURITY;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_customer_accounts_user_id ON customer_accounts(user_id);
CREATE INDEX IF NOT EXISTS idx_customer_accounts_username ON customer_accounts(username);
CREATE INDEX IF NOT EXISTS idx_customer_accounts_email ON customer_accounts(email);

-- RLS Policies
CREATE POLICY "Customers can read own account"
  ON customer_accounts FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Customers can update own account"
  ON customer_accounts FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Customers can create own account"
  ON customer_accounts FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Anyone can read public customer profiles"
  ON customer_accounts FOR SELECT
  TO authenticated
  USING (account_status = 'active');

-- Trigger
CREATE TRIGGER update_customer_accounts_updated_at
  BEFORE UPDATE ON customer_accounts
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- 3. HOMEMAKER ACCOUNTS TABLE (Instagram-like business profiles)
-- =====================================================
CREATE TABLE IF NOT EXISTS homemaker_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  username text UNIQUE,
  business_name text NOT NULL,
  display_name text NOT NULL,
  email text UNIQUE NOT NULL,
  phone text NOT NULL,
  profile_image_url text,
  cover_image_url text,
  bio text,
  business_description text NOT NULL,
  specialties text[] DEFAULT '{}',
  cuisine_types text[] DEFAULT '{}',
  experience_years integer DEFAULT 0,
  certifications text[],
  rating numeric(3,2) DEFAULT 0 CHECK (rating >= 0 AND rating <= 5),
  total_reviews integer DEFAULT 0,
  total_orders integer DEFAULT 0,
  is_verified boolean DEFAULT false,
  verification_status text DEFAULT 'pending' CHECK (verification_status IN ('pending', 'verified', 'rejected')),
  is_active boolean DEFAULT true,
  account_status text DEFAULT 'active' CHECK (account_status IN ('active', 'suspended', 'deactivated')),
  business_license text,
  fssai_license text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE homemaker_accounts ENABLE ROW LEVEL SECURITY;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_homemaker_accounts_user_id ON homemaker_accounts(user_id);
CREATE INDEX IF NOT EXISTS idx_homemaker_accounts_username ON homemaker_accounts(username);
CREATE INDEX IF NOT EXISTS idx_homemaker_accounts_business_name ON homemaker_accounts(business_name);
CREATE INDEX IF NOT EXISTS idx_homemaker_accounts_rating ON homemaker_accounts(rating DESC);

-- RLS Policies
CREATE POLICY "Homemakers can read own account"
  ON homemaker_accounts FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Homemakers can update own account"
  ON homemaker_accounts FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Homemakers can create own account"
  ON homemaker_accounts FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Anyone can read active verified homemaker profiles"
  ON homemaker_accounts FOR SELECT
  TO authenticated
  USING (is_active = true AND verification_status = 'verified' AND account_status = 'active');

-- Trigger
CREATE TRIGGER update_homemaker_accounts_updated_at
  BEFORE UPDATE ON homemaker_accounts
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- 4. HOMEMAKER PROFILES TABLE (Legacy compatibility)
-- =====================================================
CREATE TABLE IF NOT EXISTS homemaker_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  business_name text NOT NULL,
  description text NOT NULL,
  specialties text[] DEFAULT '{}',
  rating numeric(3,2) DEFAULT 0 CHECK (rating >= 0 AND rating <= 5),
  total_reviews integer DEFAULT 0,
  is_active boolean DEFAULT true,
  verification_status verification_status DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE homemaker_profiles ENABLE ROW LEVEL SECURITY;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_homemaker_profiles_user_id ON homemaker_profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_homemaker_profiles_rating ON homemaker_profiles(rating DESC);

-- RLS Policies
CREATE POLICY "Anyone can read active homemaker profiles"
  ON homemaker_profiles FOR SELECT
  TO authenticated
  USING (is_active = true AND verification_status = 'verified');

CREATE POLICY "Homemakers can create own profile"
  ON homemaker_profiles FOR INSERT
  TO authenticated
  WITH CHECK (user_id IN (
    SELECT id FROM profiles WHERE id = auth.uid()
  ));

CREATE POLICY "Homemakers can manage own profile"
  ON homemaker_profiles FOR ALL
  TO authenticated
  USING (user_id = auth.uid());

-- Trigger
CREATE TRIGGER update_homemaker_profiles_updated_at
  BEFORE UPDATE ON homemaker_profiles
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- 5. MEAL PLANS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS meal_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  homemaker_id uuid NOT NULL REFERENCES homemaker_profiles(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text NOT NULL,
  price_per_day numeric(10,2) NOT NULL CHECK (price_per_day > 0),
  meal_type meal_type NOT NULL,
  is_available boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE meal_plans ENABLE ROW LEVEL SECURITY;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_meal_plans_homemaker_id ON meal_plans(homemaker_id);
CREATE INDEX IF NOT EXISTS idx_meal_plans_meal_type ON meal_plans(meal_type);

-- RLS Policies
CREATE POLICY "Anyone can read available meal plans"
  ON meal_plans FOR SELECT
  TO authenticated
  USING (is_available = true);

CREATE POLICY "Homemakers can manage own meal plans"
  ON meal_plans FOR ALL
  TO authenticated
  USING (homemaker_id IN (
    SELECT id FROM homemaker_profiles WHERE user_id = auth.uid()
  ));

-- Trigger
CREATE TRIGGER update_meal_plans_updated_at
  BEFORE UPDATE ON meal_plans
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- 6. SUBSCRIPTIONS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  meal_plan_id uuid NOT NULL REFERENCES meal_plans(id) ON DELETE CASCADE,
  start_date date NOT NULL,
  end_date date NOT NULL,
  status subscription_status DEFAULT 'active',
  subscription_type subscription_type NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_subscriptions_customer_id ON subscriptions(customer_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_meal_plan_id ON subscriptions(meal_plan_id);

-- RLS Policies
CREATE POLICY "Customers can read own subscriptions"
  ON subscriptions FOR SELECT
  TO authenticated
  USING (customer_id = auth.uid());

CREATE POLICY "Customers can create subscriptions"
  ON subscriptions FOR INSERT
  TO authenticated
  WITH CHECK (customer_id = auth.uid());

CREATE POLICY "Customers can update own subscriptions"
  ON subscriptions FOR UPDATE
  TO authenticated
  USING (customer_id = auth.uid());

-- Trigger
CREATE TRIGGER update_subscriptions_updated_at
  BEFORE UPDATE ON subscriptions
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- 7. REVIEWS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  homemaker_id uuid NOT NULL REFERENCES homemaker_profiles(id) ON DELETE CASCADE,
  subscription_id uuid NOT NULL REFERENCES subscriptions(id) ON DELETE CASCADE,
  rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_reviews_customer_id ON reviews(customer_id);
CREATE INDEX IF NOT EXISTS idx_reviews_homemaker_id ON reviews(homemaker_id);

-- RLS Policies
CREATE POLICY "Anyone can read reviews"
  ON reviews FOR SELECT
  TO authenticated;

CREATE POLICY "Customers can create reviews for their subscriptions"
  ON reviews FOR INSERT
  TO authenticated
  WITH CHECK (
    customer_id = auth.uid() AND 
    subscription_id IN (
      SELECT id FROM subscriptions WHERE customer_id = auth.uid()
    )
  );

CREATE POLICY "Customers can update own reviews"
  ON reviews FOR UPDATE
  TO authenticated
  USING (customer_id = auth.uid());

-- Trigger to update homemaker rating when review is added/updated
CREATE TRIGGER update_homemaker_rating_trigger
  AFTER INSERT OR UPDATE ON reviews
  FOR EACH ROW
  EXECUTE FUNCTION update_homemaker_rating();

-- Trigger for updated_at
CREATE TRIGGER update_reviews_updated_at
  BEFORE UPDATE ON reviews
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- 8. DAILY REPORTS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS daily_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  homemaker_id uuid NOT NULL REFERENCES homemaker_profiles(id) ON DELETE CASCADE,
  report_date date NOT NULL,
  full_day_recipes text[] DEFAULT '{}',
  instant_recipes text[] DEFAULT '{}',
  breakfast_specialties text[] DEFAULT '{}',
  lunch_specialties text[] DEFAULT '{}',
  dinner_specialties text[] DEFAULT '{}',
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(homemaker_id, report_date)
);

-- Enable RLS
ALTER TABLE daily_reports ENABLE ROW LEVEL SECURITY;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_daily_reports_homemaker_date ON daily_reports(homemaker_id, report_date);
CREATE INDEX IF NOT EXISTS idx_daily_reports_date_active ON daily_reports(report_date, is_active);

-- RLS Policies
CREATE POLICY "Anyone can read active daily reports"
  ON daily_reports FOR SELECT
  TO authenticated
  USING (is_active = true);

CREATE POLICY "Homemakers can manage own daily reports"
  ON daily_reports FOR ALL
  TO authenticated
  USING (homemaker_id IN (
    SELECT id FROM homemaker_profiles WHERE user_id = auth.uid()
  ))
  WITH CHECK (homemaker_id IN (
    SELECT id FROM homemaker_profiles WHERE user_id = auth.uid()
  ));

-- Trigger
CREATE TRIGGER update_daily_reports_updated_at
  BEFORE UPDATE ON daily_reports
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- 9. CUSTOMER ADDRESSES TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS customer_addresses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES customer_accounts(id) ON DELETE CASCADE,
  address_type text DEFAULT 'home' CHECK (address_type IN ('home', 'work', 'other')),
  address_line_1 text NOT NULL,
  address_line_2 text,
  city text NOT NULL,
  state text NOT NULL,
  postal_code text NOT NULL,
  landmark text,
  delivery_instructions text,
  is_default boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE customer_addresses ENABLE ROW LEVEL SECURITY;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_customer_addresses_customer_id ON customer_addresses(customer_id);

-- RLS Policies
CREATE POLICY "Customers can manage own addresses"
  ON customer_addresses FOR ALL
  TO authenticated
  USING (customer_id IN (
    SELECT id FROM customer_accounts WHERE user_id = auth.uid()
  ));

-- Trigger
CREATE TRIGGER update_customer_addresses_updated_at
  BEFORE UPDATE ON customer_addresses
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- 10. HOMEMAKER SERVICE AREAS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS homemaker_service_areas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  homemaker_id uuid NOT NULL REFERENCES homemaker_accounts(id) ON DELETE CASCADE,
  area_name text NOT NULL,
  city text NOT NULL,
  state text NOT NULL,
  postal_codes text[],
  delivery_fee numeric(8,2) DEFAULT 0,
  minimum_order_amount numeric(10,2) DEFAULT 0,
  delivery_time_minutes integer DEFAULT 30,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE homemaker_service_areas ENABLE ROW LEVEL SECURITY;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_homemaker_service_areas_homemaker_id ON homemaker_service_areas(homemaker_id);

-- RLS Policies
CREATE POLICY "Anyone can read active service areas"
  ON homemaker_service_areas FOR SELECT
  TO authenticated
  USING (is_active = true);

CREATE POLICY "Homemakers can manage own service areas"
  ON homemaker_service_areas FOR ALL
  TO authenticated
  USING (homemaker_id IN (
    SELECT id FROM homemaker_accounts WHERE user_id = auth.uid()
  ));

-- Trigger
CREATE TRIGGER update_homemaker_service_areas_updated_at
  BEFORE UPDATE ON homemaker_service_areas
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- 11. CUSTOMER PREFERENCES TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS customer_preferences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES customer_accounts(id) ON DELETE CASCADE,
  preferred_meal_times jsonb DEFAULT '{}',
  spice_level text DEFAULT 'medium' CHECK (spice_level IN ('mild', 'medium', 'spicy', 'extra_spicy')),
  portion_size text DEFAULT 'regular' CHECK (portion_size IN ('small', 'regular', 'large')),
  dietary_preferences text[] DEFAULT '{}',
  allergies text[] DEFAULT '{}',
  favorite_cuisines text[] DEFAULT '{}',
  disliked_ingredients text[] DEFAULT '{}',
  notification_preferences jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE customer_preferences ENABLE ROW LEVEL SECURITY;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_customer_preferences_customer_id ON customer_preferences(customer_id);

-- RLS Policies
CREATE POLICY "Customers can manage own preferences"
  ON customer_preferences FOR ALL
  TO authenticated
  USING (customer_id IN (
    SELECT id FROM customer_accounts WHERE user_id = auth.uid()
  ));

-- Trigger
CREATE TRIGGER update_customer_preferences_updated_at
  BEFORE UPDATE ON customer_preferences
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- 12. HOMEMAKER BUSINESS DETAILS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS homemaker_business_details (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  homemaker_id uuid NOT NULL REFERENCES homemaker_accounts(id) ON DELETE CASCADE,
  kitchen_type text CHECK (kitchen_type IN ('home_kitchen', 'commercial_kitchen', 'cloud_kitchen')),
  kitchen_capacity integer DEFAULT 10,
  operating_hours jsonb DEFAULT '{}',
  operating_days text[] DEFAULT '{}',
  advance_booking_days integer DEFAULT 1,
  cancellation_policy text,
  refund_policy text,
  payment_methods text[] DEFAULT '{}',
  bank_account_details jsonb,
  tax_details jsonb,
  insurance_details jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE homemaker_business_details ENABLE ROW LEVEL SECURITY;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_homemaker_business_details_homemaker_id ON homemaker_business_details(homemaker_id);

-- RLS Policies
CREATE POLICY "Homemakers can manage own business details"
  ON homemaker_business_details FOR ALL
  TO authenticated
  USING (homemaker_id IN (
    SELECT id FROM homemaker_accounts WHERE user_id = auth.uid()
  ));

-- Trigger
CREATE TRIGGER update_homemaker_business_details_updated_at
  BEFORE UPDATE ON homemaker_business_details
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- 13. USER PROFILES TABLE (Additional user management)
-- =====================================================
CREATE TABLE IF NOT EXISTS user_profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text UNIQUE NOT NULL,
  full_name text NOT NULL,
  phone text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "user_profiles_select_policy"
  ON user_profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "user_profiles_insert_policy"
  ON user_profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

CREATE POLICY "user_profiles_update_policy"
  ON user_profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

-- Trigger
CREATE TRIGGER update_user_profiles_updated_at
  BEFORE UPDATE ON user_profiles
  FOR EACH ROW
  EXECUTE FUNCTION update_user_updated_at_column();

-- =====================================================
-- 14. USER SUBSCRIPTIONS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS user_subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  plan_type text NOT NULL CHECK (plan_type IN ('breakfast', 'lunch', 'supper', 'combo')),
  duration text NOT NULL CHECK (duration IN ('monthly', 'quarterly', 'yearly')),
  start_date date NOT NULL,
  end_date date NOT NULL,
  price_per_day integer NOT NULL,
  delivery_address text NOT NULL,
  delivery_time text NOT NULL,
  dietary_preferences text DEFAULT '',
  status text DEFAULT 'active' CHECK (status IN ('active', 'paused', 'cancelled', 'expired')),
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE user_subscriptions ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "user_subscriptions_select_policy"
  ON user_subscriptions FOR SELECT
  TO authenticated
  USING (profile_id = auth.uid());

CREATE POLICY "user_subscriptions_insert_policy"
  ON user_subscriptions FOR INSERT
  TO authenticated
  WITH CHECK (profile_id = auth.uid());

CREATE POLICY "user_subscriptions_update_policy"
  ON user_subscriptions FOR UPDATE
  TO authenticated
  USING (profile_id = auth.uid());

-- =====================================================
-- 15. USER EVENT BOOKINGS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS user_event_bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  event_date date NOT NULL,
  event_time time NOT NULL,
  guest_count text NOT NULL,
  meal_type text NOT NULL,
  cuisine text NOT NULL,
  budget text NOT NULL,
  address text NOT NULL,
  special_requests text DEFAULT '',
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'completed', 'cancelled')),
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE user_event_bookings ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "user_event_bookings_select_policy"
  ON user_event_bookings FOR SELECT
  TO authenticated
  USING (profile_id = auth.uid());

CREATE POLICY "user_event_bookings_insert_policy"
  ON user_event_bookings FOR INSERT
  TO authenticated
  WITH CHECK (profile_id = auth.uid());

CREATE POLICY "user_event_bookings_update_policy"
  ON user_event_bookings FOR UPDATE
  TO authenticated
  USING (profile_id = auth.uid());

-- =====================================================
-- 16. USER DEMO BOOKINGS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS user_demo_bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid REFERENCES user_profiles(id) ON DELETE SET NULL,
  name text NOT NULL,
  phone text NOT NULL,
  address text NOT NULL,
  preferred_date date NOT NULL,
  time_slot text NOT NULL,
  meal_preference text NOT NULL,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'delivered', 'cancelled')),
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE user_demo_bookings ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "user_demo_bookings_select_policy"
  ON user_demo_bookings FOR SELECT
  TO authenticated
  USING (profile_id = auth.uid() OR profile_id IS NULL);

CREATE POLICY "user_demo_bookings_insert_policy"
  ON user_demo_bookings FOR INSERT
  TO anon, authenticated
  USING (true);

-- =====================================================
-- SAMPLE DATA (Optional - for testing)
-- =====================================================

-- Insert sample customer account
INSERT INTO customer_accounts (
  user_id, display_name, email, bio, preferred_cuisine, dietary_restrictions
) VALUES (
  gen_random_uuid(),
  'John Doe',
  'john@example.com',
  'Food lover from Bangalore',
  ARRAY['North Indian', 'South Indian'],
  ARRAY['Vegetarian']
) ON CONFLICT DO NOTHING;

-- Insert sample homemaker account
INSERT INTO homemaker_accounts (
  user_id, business_name, display_name, email, phone, business_description, specialties, verification_status
) VALUES (
  gen_random_uuid(),
  'Amma''s Kitchen',
  'Priya Sharma',
  'priya@example.com',
  '+91-9876543210',
  'Traditional home-style cooking with love',
  ARRAY['South Indian', 'North Indian', 'Snacks'],
  'verified'
) ON CONFLICT DO NOTHING;

-- =====================================================
-- USEFUL QUERIES FOR DEVELOPMENT
-- =====================================================

-- Query to get all customers with their preferences
/*
SELECT 
  ca.*,
  cp.spice_level,
  cp.dietary_preferences,
  cp.favorite_cuisines
FROM customer_accounts ca
LEFT JOIN customer_preferences cp ON ca.id = cp.customer_id
WHERE ca.account_status = 'active';
*/

-- Query to get all verified homemakers with their meal plans
/*
SELECT 
  ha.business_name,
  ha.display_name,
  ha.rating,
  ha.total_reviews,
  mp.name as meal_plan_name,
  mp.price_per_day,
  mp.meal_type
FROM homemaker_accounts ha
LEFT JOIN homemaker_profiles hp ON ha.user_id = hp.user_id
LEFT JOIN meal_plans mp ON hp.id = mp.homemaker_id
WHERE ha.verification_status = 'verified' 
  AND ha.is_active = true
  AND mp.is_available = true;
*/

-- Query to get daily reports for today
/*
SELECT 
  dr.*,
  ha.business_name,
  ha.display_name
FROM daily_reports dr
JOIN homemaker_profiles hp ON dr.homemaker_id = hp.id
JOIN homemaker_accounts ha ON hp.user_id = ha.user_id
WHERE dr.report_date = CURRENT_DATE
  AND dr.is_active = true;
*/

-- =====================================================
-- END OF SCHEMA
-- =====================================================