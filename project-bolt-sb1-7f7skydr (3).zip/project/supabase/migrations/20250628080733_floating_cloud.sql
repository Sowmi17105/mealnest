/*
  # Add Daily Reports Feature

  1. New Tables
    - `daily_reports`
      - `id` (uuid, primary key)
      - `homemaker_id` (uuid, foreign key to homemaker_profiles)
      - `report_date` (date)
      - `full_day_recipes` (text array)
      - `instant_recipes` (text array)
      - `breakfast_specialties` (text array)
      - `lunch_specialties` (text array)
      - `dinner_specialties` (text array)
      - `is_active` (boolean)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `daily_reports` table
    - Add policies for homemakers to manage their own reports
    - Add policy for customers to read active reports

  3. Indexes
    - Index on homemaker_id and report_date for efficient queries
*/

CREATE TABLE IF NOT EXISTS daily_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  homemaker_id uuid NOT NULL REFERENCES homemaker_profiles(id) ON DELETE CASCADE,
  report_date date NOT NULL,
  full_day_recipes text[] DEFAULT '{}',
  instant_recipes text[] DEFAULT '{}',
  breakfast_specialties text[] DEFAULT '{}',
  lunch_specialties text[] DEFAULT '{}',
  dinner_specialties text[] DEFAULT '{}',
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE daily_reports ENABLE ROW LEVEL SECURITY;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_daily_reports_homemaker_date 
  ON daily_reports(homemaker_id, report_date);
CREATE INDEX IF NOT EXISTS idx_daily_reports_date_active 
  ON daily_reports(report_date, is_active);

-- RLS Policies
CREATE POLICY "Homemakers can manage own daily reports"
  ON daily_reports
  FOR ALL
  TO authenticated
  USING (homemaker_id IN (
    SELECT id FROM homemaker_profiles WHERE user_id = auth.uid()
  ))
  WITH CHECK (homemaker_id IN (
    SELECT id FROM homemaker_profiles WHERE user_id = auth.uid()
  ));

CREATE POLICY "Anyone can read active daily reports"
  ON daily_reports
  FOR SELECT
  TO authenticated
  USING (is_active = true);

-- Trigger for updated_at
CREATE TRIGGER update_daily_reports_updated_at
  BEFORE UPDATE ON daily_reports
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Unique constraint to prevent duplicate reports for same homemaker on same date
ALTER TABLE daily_reports 
ADD CONSTRAINT unique_homemaker_date 
UNIQUE (homemaker_id, report_date);