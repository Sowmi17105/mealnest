import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase, testConnection } from '../lib/supabase';

interface AuthContextType {
  user: User | null;
  session: Session | null;
  loading: boolean;
  signUp: (email: string, password: string, userData: any) => Promise<any>;
  signIn: (email: string, password: string) => Promise<any>;
  signOut: () => Promise<void>;
  userProfile: any;
  customerAccount: any;
  homemakerAccount: any;
  refreshUserData: () => Promise<void>;
  connectionStatus: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [userProfile, setUserProfile] = useState<any>(null);
  const [customerAccount, setCustomerAccount] = useState<any>(null);
  const [homemakerAccount, setHomemakerAccount] = useState<any>(null);
  const [connectionStatus, setConnectionStatus] = useState(false);

  useEffect(() => {
    let mounted = true;
    
    const initializeAuth = async () => {
      try {
        // Test connection first
        const isConnected = await testConnection();
        if (mounted) {
          setConnectionStatus(isConnected);
        }

        if (!isConnected) {
          console.warn('Supabase connection failed, retrying...');
          // Retry connection after 2 seconds
          setTimeout(() => {
            if (mounted) {
              initializeAuth();
            }
          }, 2000);
          return;
        }

        // Get current session with retry logic
        let retryCount = 0;
        const maxRetries = 3;
        
        while (retryCount < maxRetries && mounted) {
          try {
            const { data: { session: currentSession }, error } = await supabase.auth.getSession();
            
            if (error) {
              console.error('Session error:', error);
              retryCount++;
              if (retryCount < maxRetries) {
                await new Promise(resolve => setTimeout(resolve, 1000 * retryCount));
                continue;
              }
              // Clear stale session on final retry
              await supabase.auth.signOut();
              if (mounted) {
                setSession(null);
                setUser(null);
                setUserProfile(null);
                setCustomerAccount(null);
                setHomemakerAccount(null);
                setLoading(false);
              }
              return;
            }

            if (mounted) {
              setSession(currentSession);
              setUser(currentSession?.user ?? null);
              
              if (currentSession?.user) {
                await fetchUserData(currentSession.user.id);
              } else {
                setLoading(false);
              }
            }
            break;
          } catch (error) {
            console.error('Auth initialization error:', error);
            retryCount++;
            if (retryCount < maxRetries && mounted) {
              await new Promise(resolve => setTimeout(resolve, 1000 * retryCount));
            } else {
              if (mounted) {
                setLoading(false);
              }
            }
          }
        }
      } catch (error) {
        console.error('Error initializing auth:', error);
        if (mounted) {
          setLoading(false);
        }
      }
    };

    initializeAuth();

    // Listen for auth changes with error handling
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        if (!mounted) return;
        
        console.log('Auth state changed:', event, session?.user?.email);
        
        try {
          setSession(session);
          setUser(session?.user ?? null);
          
          if (session?.user) {
            await fetchUserData(session.user.id);
          } else {
            setUserProfile(null);
            setCustomerAccount(null);
            setHomemakerAccount(null);
            setLoading(false);
          }
        } catch (error) {
          console.error('Auth state change error:', error);
          if (mounted) {
            setLoading(false);
          }
        }
      }
    );

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []);

  const fetchUserData = async (userId: string) => {
    try {
      console.log('Fetching user data for:', userId);
      
      // Fetch basic profile with retry logic
      let retryCount = 0;
      const maxRetries = 3;
      let profile = null;
      
      while (retryCount < maxRetries) {
        try {
          const { data: profileData, error: profileError } = await supabase
            .from('profiles')
            .select('*')
            .eq('id', userId)
            .single();

          if (profileError) {
            if (profileError.code === 'PGRST116') {
              console.log('Profile not found, user might be registering...');
              return;
            }
            throw profileError;
          }
          
          profile = profileData;
          break;
        } catch (error) {
          console.error(`Profile fetch attempt ${retryCount + 1} failed:`, error);
          retryCount++;
          if (retryCount < maxRetries) {
            await new Promise(resolve => setTimeout(resolve, 1000 * retryCount));
          } else {
            throw error;
          }
        }
      }
      
      if (!profile) {
        setLoading(false);
        return;
      }
      
      console.log('Profile fetched:', profile);
      setUserProfile(profile);

      // Fetch specific account type data with error handling
      try {
        if (profile.user_type === 'customer') {
          const { data: customerData, error: customerError } = await supabase
            .from('customer_accounts')
            .select('*')
            .eq('user_id', userId);

          if (customerError) {
            console.error('Error fetching customer account:', customerError);
          } else if (customerData && customerData.length > 0) {
            console.log('Customer account fetched:', customerData[0]);
            setCustomerAccount(customerData[0]);
          }
        } else if (profile.user_type === 'homemaker') {
          const { data: homemakerData, error: homemakerError } = await supabase
            .from('homemaker_accounts')
            .select('*')
            .eq('user_id', userId);

          if (homemakerError) {
            console.error('Error fetching homemaker account:', homemakerError);
          } else if (homemakerData && homemakerData.length > 0) {
            console.log('Homemaker account fetched:', homemakerData[0]);
            setHomemakerAccount(homemakerData[0]);
          }
        }
      } catch (error) {
        console.error('Error fetching account data:', error);
      }
      
      setLoading(false);
      
    } catch (error) {
      console.error('Error fetching user data:', error);
      setLoading(false);
    }
  };

  const refreshUserData = async () => {
    if (user) {
      setLoading(true);
      await fetchUserData(user.id);
    }
  };

  const signUp = async (email: string, password: string, userData: any) => {
    try {
      console.log('Signing up user:', email, userData);
      
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
      });

      if (error) throw error;

      if (data.user) {
        console.log('User created, creating profile...');
        
        // Create basic profile with retry logic
        let retryCount = 0;
        const maxRetries = 3;
        
        while (retryCount < maxRetries) {
          try {
            const { error: profileError } = await supabase
              .from('profiles')
              .insert({
                id: data.user.id,
                email: data.user.email!,
                full_name: userData.fullName,
                user_type: userData.userType,
                phone: userData.phone || null,
                address: userData.address || null,
              });

            if (profileError) throw profileError;
            break;
          } catch (error) {
            console.error(`Profile creation attempt ${retryCount + 1} failed:`, error);
            retryCount++;
            if (retryCount < maxRetries) {
              await new Promise(resolve => setTimeout(resolve, 1000 * retryCount));
            } else {
              throw error;
            }
          }
        }

        // Create specific account type with retry logic
        retryCount = 0;
        while (retryCount < maxRetries) {
          try {
            if (userData.userType === 'customer') {
              console.log('Creating customer account...');
              
              const { error: customerError } = await supabase
                .from('customer_accounts')
                .insert({
                  user_id: data.user.id,
                  display_name: userData.fullName,
                  email: data.user.email!,
                  phone: userData.phone || null,
                  bio: `Welcome to Mealnest! I'm ${userData.fullName.split(' ')[0]} and I love good food.`,
                  preferred_cuisine: [],
                  dietary_restrictions: [],
                  is_verified: false,
                  account_status: 'active',
                  total_orders: 0,
                  total_spent: 0,
                  loyalty_points: 0,
                });

              if (customerError) throw customerError;
            } else if (userData.userType === 'homemaker') {
              console.log('Creating homemaker account...');
              
              const { error: homemakerError } = await supabase
                .from('homemaker_accounts')
                .insert({
                  user_id: data.user.id,
                  business_name: userData.businessName,
                  display_name: userData.fullName,
                  email: data.user.email!,
                  phone: userData.phone || '',
                  business_description: userData.description,
                  specialties: userData.specialties || [],
                  cuisine_types: [],
                  experience_years: 0,
                  certifications: [],
                  is_verified: false,
                  verification_status: 'pending',
                  is_active: false,
                  account_status: 'pending',
                  rating: 0,
                  total_reviews: 0,
                  total_orders: 0,
                });

              if (homemakerError) throw homemakerError;

              // Also create legacy homemaker_profiles for backward compatibility
              try {
                const { error: legacyError } = await supabase
                  .from('homemaker_profiles')
                  .insert({
                    user_id: data.user.id,
                    business_name: userData.businessName,
                    description: userData.description,
                    specialties: userData.specialties || [],
                    rating: 0,
                    total_reviews: 0,
                    is_active: false,
                    verification_status: 'pending',
                  });

                if (legacyError) {
                  console.error('Legacy homemaker profile creation error:', legacyError);
                }
              } catch (error) {
                console.error('Legacy profile creation failed:', error);
              }
            }
            break;
          } catch (error) {
            console.error(`Account creation attempt ${retryCount + 1} failed:`, error);
            retryCount++;
            if (retryCount < maxRetries) {
              await new Promise(resolve => setTimeout(resolve, 1000 * retryCount));
            } else {
              throw error;
            }
          }
        }
        
        console.log('Sign up completed successfully');
        
        // Refresh user data after successful signup
        await fetchUserData(data.user.id);
      }

      return data;
    } catch (error) {
      console.error('Sign up error:', error);
      throw error;
    }
  };

  const signIn = async (email: string, password: string) => {
    try {
      console.log('Signing in user:', email);
      
      let retryCount = 0;
      const maxRetries = 3;
      
      while (retryCount < maxRetries) {
        try {
          const { data, error } = await supabase.auth.signInWithPassword({
            email,
            password,
          });

          if (error) throw error;
          
          console.log('Sign in successful');
          return data;
        } catch (error) {
          console.error(`Sign in attempt ${retryCount + 1} failed:`, error);
          retryCount++;
          if (retryCount < maxRetries) {
            await new Promise(resolve => setTimeout(resolve, 1000 * retryCount));
          } else {
            throw error;
          }
        }
      }
    } catch (error) {
      console.error('Sign in error:', error);
      throw error;
    }
  };

  const signOut = async () => {
    try {
      console.log('Signing out user');
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      
      // Clear all state
      setUser(null);
      setSession(null);
      setUserProfile(null);
      setCustomerAccount(null);
      setHomemakerAccount(null);
      
      console.log('Sign out successful');
    } catch (error) {
      console.error('Sign out error:', error);
      throw error;
    }
  };

  const value = {
    user,
    session,
    loading,
    signUp,
    signIn,
    signOut,
    userProfile,
    customerAccount,
    homemakerAccount,
    refreshUserData,
    connectionStatus,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};