import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { ChefHat, User, Home, Mail, Phone, MapPin, Briefcase, Star, Heart, Shield } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

const AuthPage = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [userType, setUserType] = useState<'customer' | 'homemaker'>('customer');
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    fullName: '',
    phone: '',
    address: '',
    businessName: '',
    description: '',
    specialties: [] as string[],
  });

  const { signUp, signIn, user, userProfile, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  // Get redirect path from location state or default paths
  const getRedirectPath = () => {
    const from = location.state?.from?.pathname;
    if (from && from !== '/auth') {
      return from;
    }
    
    if (userProfile) {
      return userProfile.user_type === 'customer' 
        ? '/meal-plans' 
        : '/homemaker-dashboard';
    }
    
    return '/meal-plans'; // Default redirect
  };

  // Redirect authenticated users to appropriate page
  useEffect(() => {
    if (!authLoading && user && userProfile) {
      console.log('User authenticated, redirecting...', userProfile);
      const redirectPath = getRedirectPath();
      console.log('Redirecting to:', redirectPath);
      navigate(redirectPath, { replace: true });
    }
  }, [user, userProfile, authLoading, navigate, location.state]);

  // Show loading while auth is initializing
  if (authLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 to-yellow-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-orange-500 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (isLogin) {
        console.log('Attempting sign in...');
        const result = await signIn(formData.email, formData.password);
        console.log('Sign in result:', result);
        
        // Navigation will be handled by useEffect after userProfile is loaded
      } else {
        console.log('Attempting sign up...');
        const result = await signUp(formData.email, formData.password, {
          fullName: formData.fullName,
          userType,
          phone: formData.phone,
          address: formData.address,
          businessName: formData.businessName,
          description: formData.description,
          specialties: formData.specialties,
        });
        
        console.log('Sign up result:', result);
        
        if (result.user && !result.user.email_confirmed_at) {
          alert('Account created successfully! Please check your email to verify your account before signing in.');
          setIsLogin(true); // Switch to login mode
          setLoading(false);
          return;
        }
        
        // Navigation will be handled by useEffect after userProfile is loaded
      }
    } catch (error: any) {
      console.error('Auth error:', error);
      alert(error.message || 'An error occurred during authentication');
      setLoading(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-yellow-50 to-red-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl w-full">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
          {/* Left Side - Branding */}
          <div className="text-center lg:text-left">
            <div className="flex justify-center lg:justify-start mb-6">
              <div className="bg-orange-500 p-4 rounded-2xl">
                <ChefHat className="h-12 w-12 text-white" />
              </div>
            </div>
            <h1 className="text-4xl font-bold text-gray-900 mb-4">
              Welcome to Mealnest
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              For the Busy You, from the Caring Few
            </p>
            
            {/* Benefits */}
            <div className="space-y-4 mb-8">
              <div className="flex items-center justify-center lg:justify-start space-x-3">
                <div className="bg-green-100 p-2 rounded-full">
                  <Heart className="h-5 w-5 text-green-600" />
                </div>
                <span className="text-gray-700">Made with love by home cooks</span>
              </div>
              <div className="flex items-center justify-center lg:justify-start space-x-3">
                <div className="bg-blue-100 p-2 rounded-full">
                  <Shield className="h-5 w-5 text-blue-600" />
                </div>
                <span className="text-gray-700">Verified and quality assured</span>
              </div>
              <div className="flex items-center justify-center lg:justify-start space-x-3">
                <div className="bg-purple-100 p-2 rounded-full">
                  <Star className="h-5 w-5 text-purple-600" />
                </div>
                <span className="text-gray-700">Trusted by 10,000+ customers</span>
              </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <div className="text-2xl font-bold text-orange-500">500+</div>
                <div className="text-sm text-gray-600">Home Cooks</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-green-500">4.9</div>
                <div className="text-sm text-gray-600">Rating</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-blue-500">50+</div>
                <div className="text-sm text-gray-600">Cities</div>
              </div>
            </div>
          </div>

          {/* Right Side - Auth Form */}
          <div className="bg-white rounded-2xl shadow-2xl p-8">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-900">
                {isLogin ? 'Sign In' : 'Create Account'}
              </h2>
              <p className="mt-2 text-sm text-gray-600">
                {isLogin ? 'Welcome back to Mealnest!' : 'Join our community today'}
              </p>
            </div>

            {!isLogin && (
              <div className="flex space-x-4 mb-6">
                <button
                  type="button"
                  onClick={() => setUserType('customer')}
                  className={`flex-1 p-4 rounded-xl border-2 transition-all duration-300 ${
                    userType === 'customer'
                      ? 'border-orange-500 bg-orange-50 shadow-md'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <User className="h-6 w-6 mx-auto mb-2 text-orange-500" />
                  <div className="text-sm font-medium">Customer</div>
                  <div className="text-xs text-gray-500">Order meals</div>
                </button>
                <button
                  type="button"
                  onClick={() => setUserType('homemaker')}
                  className={`flex-1 p-4 rounded-xl border-2 transition-all duration-300 ${
                    userType === 'homemaker'
                      ? 'border-orange-500 bg-orange-50 shadow-md'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <Home className="h-6 w-6 mx-auto mb-2 text-orange-500" />
                  <div className="text-sm font-medium">Home Cook</div>
                  <div className="text-xs text-gray-500">Sell meals</div>
                </button>
              </div>
            )}

            <form className="space-y-4" onSubmit={handleSubmit}>
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                  Email address
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                  <input
                    id="email"
                    name="email"
                    type="email"
                    required
                    value={formData.email}
                    onChange={handleInputChange}
                    className="pl-10 block w-full rounded-lg border border-gray-300 px-3 py-2 focus:border-orange-500 focus:ring-orange-500"
                    placeholder="Enter your email"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                  Password
                </label>
                <input
                  id="password"
                  name="password"
                  type="password"
                  required
                  value={formData.password}
                  onChange={handleInputChange}
                  className="block w-full rounded-lg border border-gray-300 px-3 py-2 focus:border-orange-500 focus:ring-orange-500"
                  placeholder="Enter your password"
                />
              </div>

              {!isLogin && (
                <>
                  <div>
                    <label htmlFor="fullName" className="block text-sm font-medium text-gray-700 mb-1">
                      Full Name
                    </label>
                    <input
                      id="fullName"
                      name="fullName"
                      type="text"
                      required
                      value={formData.fullName}
                      onChange={handleInputChange}
                      className="block w-full rounded-lg border border-gray-300 px-3 py-2 focus:border-orange-500 focus:ring-orange-500"
                      placeholder="Enter your full name"
                    />
                  </div>

                  <div>
                    <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                      Phone Number
                    </label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                      <input
                        id="phone"
                        name="phone"
                        type="tel"
                        value={formData.phone}
                        onChange={handleInputChange}
                        className="pl-10 block w-full rounded-lg border border-gray-300 px-3 py-2 focus:border-orange-500 focus:ring-orange-500"
                        placeholder="Enter your phone number"
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="address" className="block text-sm font-medium text-gray-700 mb-1">
                      Address
                    </label>
                    <div className="relative">
                      <MapPin className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                      <input
                        id="address"
                        name="address"
                        type="text"
                        value={formData.address}
                        onChange={handleInputChange}
                        className="pl-10 block w-full rounded-lg border border-gray-300 px-3 py-2 focus:border-orange-500 focus:ring-orange-500"
                        placeholder="Enter your address"
                      />
                    </div>
                  </div>

                  {userType === 'homemaker' && (
                    <>
                      <div>
                        <label htmlFor="businessName" className="block text-sm font-medium text-gray-700 mb-1">
                          Business Name
                        </label>
                        <div className="relative">
                          <Briefcase className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                          <input
                            id="businessName"
                            name="businessName"
                            type="text"
                            required
                            value={formData.businessName}
                            onChange={handleInputChange}
                            className="pl-10 block w-full rounded-lg border border-gray-300 px-3 py-2 focus:border-orange-500 focus:ring-orange-500"
                            placeholder="Enter your kitchen/business name"
                          />
                        </div>
                      </div>

                      <div>
                        <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                          Description
                        </label>
                        <textarea
                          id="description"
                          name="description"
                          rows={3}
                          required
                          value={formData.description}
                          onChange={handleInputChange}
                          className="block w-full rounded-lg border border-gray-300 px-3 py-2 focus:border-orange-500 focus:ring-orange-500"
                          placeholder="Tell us about your cooking style and specialties"
                        />
                      </div>
                    </>
                  )}
                </>
              )}

              <div className="pt-4">
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full flex justify-center py-3 px-4 border border-transparent text-sm font-medium rounded-lg text-white bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500 disabled:opacity-50 transition-all duration-300"
                >
                  {loading ? 'Processing...' : (isLogin ? 'Sign In' : 'Create Account')}
                </button>
              </div>

              <div className="text-center pt-4">
                <button
                  type="button"
                  onClick={() => setIsLogin(!isLogin)}
                  className="text-orange-500 hover:text-orange-600 font-medium transition-colors"
                >
                  {isLogin ? "Don't have an account? Sign up" : 'Already have an account? Sign in'}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthPage;