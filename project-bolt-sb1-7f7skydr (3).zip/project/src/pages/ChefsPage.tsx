import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { Star, MapPin, ChefHat, Clock, Package, Phone, Mail, Users, TrendingUp } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import HomemakerSearch from '../components/HomemakerSearch';

const ChefsPage = () => {
  const [chefs, setChefs] = useState([]);
  const [filteredChefs, setFilteredChefs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchLoading, setSearchLoading] = useState(false);
  const [selectedChef, setSelectedChef] = useState<any>(null);
  const [stats, setStats] = useState({
    totalChefs: 0,
    averageRating: 0,
    totalMealPlans: 0
  });
  const navigate = useNavigate();

  useEffect(() => {
    fetchChefs();
  }, []);

  const fetchChefs = async () => {
    try {
      const { data, error } = await supabase
        .from('homemaker_profiles')
        .select(`
          *,
          profiles (
            full_name,
            email,
            phone,
            address
          ),
          meal_plans (
            id,
            name,
            description,
            price_per_day,
            meal_type,
            is_available
          )
        `)
        .eq('is_active', true)
        .eq('verification_status', 'verified')
        .order('rating', { ascending: false });

      if (error) throw error;
      
      const chefsData = data || [];
      setChefs(chefsData);
      setFilteredChefs(chefsData);

      // Calculate stats
      const totalChefs = chefsData.length;
      const averageRating = totalChefs > 0 
        ? chefsData.reduce((sum, chef) => sum + (chef.rating || 0), 0) / totalChefs
        : 0;
      const totalMealPlans = chefsData.reduce((sum, chef) => 
        sum + chef.meal_plans.filter((plan: any) => plan.is_available).length, 0
      );

      setStats({
        totalChefs,
        averageRating: Math.round(averageRating * 10) / 10,
        totalMealPlans
      });

    } catch (error) {
      console.error('Error fetching chefs:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSearchResults = (results: any[]) => {
    setFilteredChefs(results);
  };

  const handleViewMealPlans = (chefId: string) => {
    navigate(`/meal-plans?chef=${chefId}`);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-orange-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-orange-50 to-yellow-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">
              Meet Our Talented Home Chefs
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Discover amazing home cooks in your area who are passionate about creating 
              delicious, homemade meals just for you.
            </p>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto">
            <div className="bg-white rounded-lg shadow-md p-6 text-center">
              <div className="flex items-center justify-center mb-2">
                <Users className="h-8 w-8 text-orange-500 mr-2" />
                <span className="text-3xl font-bold text-gray-900">{stats.totalChefs}</span>
              </div>
              <p className="text-gray-600">Verified Chefs</p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6 text-center">
              <div className="flex items-center justify-center mb-2">
                <Star className="h-8 w-8 text-yellow-500 mr-2" />
                <span className="text-3xl font-bold text-gray-900">{stats.averageRating}</span>
              </div>
              <p className="text-gray-600">Average Rating</p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6 text-center">
              <div className="flex items-center justify-center mb-2">
                <Package className="h-8 w-8 text-green-500 mr-2" />
                <span className="text-3xl font-bold text-gray-900">{stats.totalMealPlans}</span>
              </div>
              <p className="text-gray-600">Meal Plans</p>
            </div>
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search Component */}
        <HomemakerSearch 
          onResults={handleSearchResults}
          onLoading={setSearchLoading}
        />

        {/* Loading State */}
        {searchLoading && (
          <div className="text-center py-8">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500 mx-auto"></div>
            <p className="text-gray-600 mt-4">Searching for chefs...</p>
          </div>
        )}

        {/* Results Summary */}
        {!searchLoading && (
          <div className="mb-6">
            <p className="text-gray-600">
              Showing {filteredChefs.length} of {chefs.length} chefs
            </p>
          </div>
        )}

        {/* Chefs Grid */}
        {!searchLoading && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredChefs.map((chef: any) => (
              <div key={chef.id} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
                <div className="p-6">
                  {/* Chef Header */}
                  <div className="flex items-center mb-4">
                    <div className="bg-orange-100 p-3 rounded-full mr-4">
                      <ChefHat className="h-8 w-8 text-orange-600" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-gray-900">{chef.business_name}</h3>
                      <p className="text-gray-600">{chef.profiles.full_name}</p>
                    </div>
                  </div>

                  {/* Rating */}
                  <div className="flex items-center mb-4">
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`h-5 w-5 ${
                            i < Math.floor(chef.rating || 0)
                              ? 'text-yellow-400 fill-current'
                              : 'text-gray-300'
                          }`}
                        />
                      ))}
                    </div>
                    <span className="ml-2 text-gray-600">
                      {chef.rating ? chef.rating.toFixed(1) : 'New'} ({chef.total_reviews} reviews)
                    </span>
                  </div>

                  {/* Description */}
                  <p className="text-gray-600 mb-4 line-clamp-3">{chef.description}</p>

                  {/* Specialties */}
                  {chef.specialties && chef.specialties.length > 0 && (
                    <div className="mb-4">
                      <h4 className="text-sm font-semibold text-gray-900 mb-2">Specialties:</h4>
                      <div className="flex flex-wrap gap-2">
                        {chef.specialties.slice(0, 3).map((specialty: string, index: number) => (
                          <span
                            key={index}
                            className="px-2 py-1 bg-orange-100 text-orange-800 text-xs rounded-full"
                          >
                            {specialty}
                          </span>
                        ))}
                        {chef.specialties.length > 3 && (
                          <span className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-full">
                            +{chef.specialties.length - 3} more
                          </span>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Location */}
                  <div className="flex items-center text-sm text-gray-500 mb-4">
                    <MapPin className="h-4 w-4 mr-1" />
                    <span>{chef.profiles.address || 'Location available on order'}</span>
                  </div>

                  {/* Meal Plans Count & Price Range */}
                  <div className="flex items-center justify-between text-sm text-gray-500 mb-6">
                    <div className="flex items-center">
                      <Package className="h-4 w-4 mr-1" />
                      <span>{chef.meal_plans.filter((plan: any) => plan.is_available).length} meal plans</span>
                    </div>
                    {chef.meal_plans.length > 0 && (
                      <div className="text-right">
                        <span className="font-semibold text-gray-900">
                          ₹{Math.min(...chef.meal_plans.filter((p: any) => p.is_available).map((p: any) => p.price_per_day))} - 
                          ₹{Math.max(...chef.meal_plans.filter((p: any) => p.is_available).map((p: any) => p.price_per_day))}
                        </span>
                        <span className="text-gray-500">/day</span>
                      </div>
                    )}
                  </div>

                  {/* Action Buttons */}
                  <div className="space-y-3">
                    <button
                      onClick={() => handleViewMealPlans(chef.id)}
                      className="w-full bg-orange-500 text-white py-2 px-4 rounded-lg hover:bg-orange-600 transition-colors font-medium"
                    >
                      View Meal Plans
                    </button>
                    <button
                      onClick={() => setSelectedChef(chef)}
                      className="w-full border border-gray-300 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-50 transition-colors"
                    >
                      View Details
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* No Results */}
        {!searchLoading && filteredChefs.length === 0 && (
          <div className="text-center py-12">
            <ChefHat className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-medium text-gray-900 mb-2">No chefs found</h3>
            <p className="text-gray-600 mb-4">
              Try adjusting your search criteria or browse all available chefs.
            </p>
            <button
              onClick={() => window.location.reload()}
              className="bg-orange-500 text-white px-6 py-2 rounded-lg hover:bg-orange-600 transition-colors"
            >
              Show All Chefs
            </button>
          </div>
        )}
      </div>

      {/* Chef Details Modal */}
      {selectedChef && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">{selectedChef.business_name}</h2>
                  <p className="text-gray-600">{selectedChef.profiles.full_name}</p>
                </div>
                <button
                  onClick={() => setSelectedChef(null)}
                  className="text-gray-400 hover:text-gray-600 text-2xl"
                >
                  ×
                </button>
              </div>

              {/* Rating */}
              <div className="flex items-center mb-6">
                <div className="flex items-center">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-6 w-6 ${
                        i < Math.floor(selectedChef.rating || 0)
                          ? 'text-yellow-400 fill-current'
                          : 'text-gray-300'
                      }`}
                    />
                  ))}
                </div>
                <span className="ml-2 text-lg text-gray-600">
                  {selectedChef.rating ? selectedChef.rating.toFixed(1) : 'New'} ({selectedChef.total_reviews} reviews)
                </span>
              </div>

              {/* Description */}
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">About</h3>
                <p className="text-gray-600">{selectedChef.description}</p>
              </div>

              {/* Specialties */}
              {selectedChef.specialties && selectedChef.specialties.length > 0 && (
                <div className="mb-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Specialties</h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedChef.specialties.map((specialty: string, index: number) => (
                      <span
                        key={index}
                        className="px-3 py-1 bg-orange-100 text-orange-800 text-sm rounded-full"
                      >
                        {specialty}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Contact Info */}
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Contact Information</h3>
                <div className="space-y-2">
                  {selectedChef.profiles.phone && (
                    <div className="flex items-center text-gray-600">
                      <Phone className="h-4 w-4 mr-2" />
                      <span>{selectedChef.profiles.phone}</span>
                    </div>
                  )}
                  <div className="flex items-center text-gray-600">
                    <Mail className="h-4 w-4 mr-2" />
                    <span>{selectedChef.profiles.email}</span>
                  </div>
                  {selectedChef.profiles.address && (
                    <div className="flex items-center text-gray-600">
                      <MapPin className="h-4 w-4 mr-2" />
                      <span>{selectedChef.profiles.address}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Available Meal Plans */}
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Available Meal Plans</h3>
                <div className="space-y-3">
                  {selectedChef.meal_plans
                    .filter((plan: any) => plan.is_available)
                    .map((plan: any) => (
                      <div key={plan.id} className="border border-gray-200 rounded-lg p-3">
                        <div className="flex justify-between items-start">
                          <div>
                            <h4 className="font-medium text-gray-900">{plan.name}</h4>
                            <p className="text-sm text-gray-600">{plan.description}</p>
                            <span className="text-xs text-gray-500 capitalize">
                              {plan.meal_type.replace('_', ' ')}
                            </span>
                          </div>
                          <span className="font-semibold text-orange-600">
                            ₹{plan.price_per_day}/day
                          </span>
                        </div>
                      </div>
                    ))}
                </div>
              </div>

              <button
                onClick={() => {
                  setSelectedChef(null);
                  handleViewMealPlans(selectedChef.id);
                }}
                className="w-full bg-orange-500 text-white py-3 px-6 rounded-lg hover:bg-orange-600 transition-colors font-semibold"
              >
                View All Meal Plans
              </button>
            </div>
          </div>
        </div>
      )}

      <Footer />
    </div>
  );
};

export default ChefsPage;