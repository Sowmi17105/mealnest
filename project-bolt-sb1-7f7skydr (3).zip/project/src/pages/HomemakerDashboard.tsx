import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { Star, Package, TrendingUp, AlertTriangle, User, LogOut, Plus, Calendar, FileText } from 'lucide-react';
import DailyReportModal from '../components/DailyReportModal';

const HomemakerDashboard = () => {
  const { user, userProfile, signOut } = useAuth();
  const [homemakerProfile, setHomemakerProfile] = useState<any>(null);
  const [mealPlans, setMealPlans] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [dailyReports, setDailyReports] = useState([]);
  const [showReportModal, setShowReportModal] = useState(false);
  const [stats, setStats] = useState({
    totalSubscriptions: 0,
    averageRating: 0,
    totalReviews: 0,
    monthlyEarnings: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchHomemakerData();
  }, [user]);

  const fetchHomemakerData = async () => {
    if (!user) return;

    try {
      // Fetch homemaker profile
      const { data: profileData } = await supabase
        .from('homemaker_profiles')
        .select('*')
        .eq('user_id', user.id)
        .single();

      // Fetch meal plans
      const { data: plansData } = await supabase
        .from('meal_plans')
        .select('*')
        .eq('homemaker_id', profileData?.id);

      // Fetch reviews
      const { data: reviewsData } = await supabase
        .from('reviews')
        .select(`
          *,
          profiles (
            full_name
          )
        `)
        .eq('homemaker_id', profileData?.id)
        .order('created_at', { ascending: false });

      // Fetch daily reports
      const { data: reportsData } = await supabase
        .from('daily_reports')
        .select('*')
        .eq('homemaker_id', profileData?.id)
        .order('report_date', { ascending: false })
        .limit(7);

      // Calculate stats
      const totalReviews = reviewsData?.length || 0;
      const averageRating = totalReviews > 0 
        ? reviewsData.reduce((sum: number, review: any) => sum + review.rating, 0) / totalReviews
        : 0;

      setHomemakerProfile(profileData);
      setMealPlans(plansData || []);
      setReviews(reviewsData || []);
      setDailyReports(reportsData || []);
      setStats({
        totalSubscriptions: 0, // This would need a more complex query
        averageRating: Math.round(averageRating * 10) / 10,
        totalReviews,
        monthlyEarnings: 0, // This would need a more complex calculation
      });

      // Update homemaker profile rating
      if (profileData && totalReviews > 0) {
        await supabase
          .from('homemaker_profiles')
          .update({
            rating: averageRating,
            total_reviews: totalReviews,
            is_active: averageRating >= 3.0, // Automatically deactivate if rating is too low
          })
          .eq('id', profileData.id);
      }

    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut();
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  const handleReportSaved = () => {
    fetchHomemakerData(); // Refresh data after saving report
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-orange-500"></div>
      </div>
    );
  }

  const isLowRating = stats.averageRating < 3.0 && stats.totalReviews >= 5;
  const todayReport = dailyReports.find(report => 
    report.report_date === new Date().toISOString().split('T')[0]
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <h1 className="text-2xl font-bold text-gray-900">Homemaker Dashboard</h1>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <User className="h-5 w-5 text-gray-400" />
                <span className="text-gray-700">{userProfile?.full_name}</span>
              </div>
              <button
                onClick={handleSignOut}
                className="flex items-center space-x-2 text-gray-600 hover:text-red-600 transition-colors"
              >
                <LogOut className="h-5 w-5" />
                <span>Sign Out</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Low Rating Warning */}
        {isLowRating && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
            <div className="flex items-center">
              <AlertTriangle className="h-5 w-5 text-red-500 mr-2" />
              <div>
                <h3 className="text-sm font-medium text-red-800">
                  Rating Alert
                </h3>
                <p className="text-sm text-red-700 mt-1">
                  Your average rating is {stats.averageRating}/5.0. Ratings below 3.0 may result in account suspension. 
                  Please improve your service quality to maintain your account status.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Today's Report Status */}
        <div className="bg-white rounded-lg shadow p-6 mb-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Calendar className="h-6 w-6 text-orange-500 mr-3" />
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Today's Report</h3>
                <p className="text-sm text-gray-600">
                  {todayReport 
                    ? `Report submitted for ${new Date().toLocaleDateString()}`
                    : `No report submitted for ${new Date().toLocaleDateString()}`
                  }
                </p>
              </div>
            </div>
            <button
              onClick={() => setShowReportModal(true)}
              className={`px-4 py-2 rounded-lg font-medium transition-colors flex items-center ${
                todayReport
                  ? 'bg-green-100 text-green-700 hover:bg-green-200'
                  : 'bg-orange-500 text-white hover:bg-orange-600'
              }`}
            >
              <FileText className="h-4 w-4 mr-2" />
              {todayReport ? 'Update Report' : 'Create Report'}
            </button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <TrendingUp className="h-8 w-8 text-green-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Average Rating</p>
                <p className="text-2xl font-bold text-gray-900">
                  {stats.averageRating || 'N/A'}
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <Star className="h-8 w-8 text-yellow-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Total Reviews</p>
                <p className="text-2xl font-bold text-gray-900">{stats.totalReviews}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <Package className="h-8 w-8 text-blue-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Active Plans</p>
                <p className="text-2xl font-bold text-gray-900">{mealPlans.length}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <FileText className="h-8 w-8 text-purple-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Daily Reports</p>
                <p className="text-2xl font-bold text-gray-900">{dailyReports.length}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Meal Plans */}
          <div className="bg-white rounded-lg shadow">
            <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
              <h2 className="text-lg font-semibold text-gray-900 flex items-center">
                <Package className="h-5 w-5 mr-2 text-orange-500" />
                Your Meal Plans
              </h2>
              <button className="bg-orange-500 text-white px-4 py-2 rounded-lg hover:bg-orange-600 transition-colors flex items-center">
                <Plus className="h-4 w-4 mr-2" />
                Add Plan
              </button>
            </div>
            <div className="p-6">
              {mealPlans.length === 0 ? (
                <div className="text-center py-8">
                  <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">No meal plans created yet</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {mealPlans.map((plan: any) => (
                    <div key={plan.id} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-semibold text-gray-900">{plan.name}</h3>
                          <p className="text-sm text-gray-600">{plan.description}</p>
                          <p className="text-sm text-gray-500 mt-1">
                            {plan.meal_type} • ₹{plan.price_per_day}/day
                          </p>
                        </div>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          plan.is_available 
                            ? 'bg-green-100 text-green-800'
                            : 'bg-gray-100 text-gray-800'
                        }`}>
                          {plan.is_available ? 'Available' : 'Unavailable'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Recent Reviews */}
          <div className="bg-white rounded-lg shadow">
            <div className="px-6 py-4 border-b border-gray-200">
              <h2 className="text-lg font-semibold text-gray-900 flex items-center">
                <Star className="h-5 w-5 mr-2 text-orange-500" />
                Recent Reviews
              </h2>
            </div>
            <div className="p-6">
              {reviews.length === 0 ? (
                <div className="text-center py-8">
                  <Star className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">No reviews yet</p>
                </div>
              ) : (
                <div className="space-y-4 max-h-96 overflow-y-auto">
                  {reviews.map((review: any) => (
                    <div key={review.id} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="font-semibold text-gray-900">
                          {review.profiles.full_name}
                        </h3>
                        <div className="flex items-center">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`h-4 w-4 ${
                                i < review.rating
                                  ? 'text-yellow-400 fill-current'
                                  : 'text-gray-300'
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                      <p className="text-gray-600">{review.comment}</p>
                      <p className="text-xs text-gray-400 mt-2">
                        {new Date(review.created_at).toLocaleDateString()}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Recent Daily Reports */}
        <div className="bg-white rounded-lg shadow mt-8">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900 flex items-center">
              <FileText className="h-5 w-5 mr-2 text-orange-500" />
              Recent Daily Reports
            </h2>
          </div>
          <div className="p-6">
            {dailyReports.length === 0 ? (
              <div className="text-center py-8">
                <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">No daily reports yet</p>
                <button
                  onClick={() => setShowReportModal(true)}
                  className="mt-4 bg-orange-500 text-white px-6 py-2 rounded-lg hover:bg-orange-600 transition-colors"
                >
                  Create Your First Report
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {dailyReports.map((report: any) => (
                  <div key={report.id} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-semibold text-gray-900">
                        {new Date(report.report_date).toLocaleDateString()}
                      </h3>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        report.is_active 
                          ? 'bg-green-100 text-green-800'
                          : 'bg-gray-100 text-gray-800'
                      }`}>
                        {report.is_active ? 'Active' : 'Inactive'}
                      </span>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
                      <div>
                        <span className="font-medium text-gray-700">Full Day: </span>
                        <span className="text-gray-600">{report.full_day_recipes.length} items</span>
                      </div>
                      <div>
                        <span className="font-medium text-gray-700">Instant: </span>
                        <span className="text-gray-600">{report.instant_recipes.length} items</span>
                      </div>
                      <div>
                        <span className="font-medium text-gray-700">Specialties: </span>
                        <span className="text-gray-600">
                          {report.breakfast_specialties.length + report.lunch_specialties.length + report.dinner_specialties.length} items
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Daily Report Modal */}
      {showReportModal && homemakerProfile && (
        <DailyReportModal
          isOpen={showReportModal}
          onClose={() => setShowReportModal(false)}
          onSave={handleReportSaved}
          homemakerId={homemakerProfile.id}
        />
      )}
    </div>
  );
};

export default HomemakerDashboard;