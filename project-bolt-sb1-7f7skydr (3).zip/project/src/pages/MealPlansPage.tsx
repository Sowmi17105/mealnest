import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { Star, Clock, MapPin, ChefHat, ShoppingCart, Calendar, Search } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import OrderModal from '../components/OrderModal';
import HomemakerSearch from '../components/HomemakerSearch';

const MealPlansPage = () => {
  const [mealPlans, setMealPlans] = useState([]);
  const [filteredPlans, setFilteredPlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchLoading, setSearchLoading] = useState(false);
  const [filter, setFilter] = useState('all');
  const [selectedPlan, setSelectedPlan] = useState<any>(null);
  const [showTodaySpecials, setShowTodaySpecials] = useState(false);
  const [searchParams] = useSearchParams();
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    fetchMealPlans();
  }, [searchParams]);

  const fetchMealPlans = async () => {
    try {
      let query = supabase
        .from('meal_plans')
        .select(`
          *,
          homemaker_profiles (
            id,
            business_name,
            rating,
            total_reviews,
            is_active,
            verification_status,
            profiles (
              full_name,
              address
            )
          )
        `)
        .eq('is_available', true)
        .eq('homemaker_profiles.is_active', true)
        .eq('homemaker_profiles.verification_status', 'verified');

      // Filter by chef if specified in URL
      const chefId = searchParams.get('chef');
      if (chefId) {
        query = query.eq('homemaker_id', chefId);
      }

      const { data, error } = await query.order('created_at', { ascending: false });

      if (error) throw error;
      const plansData = data || [];
      setMealPlans(plansData);
      setFilteredPlans(plansData);
    } catch (error) {
      console.error('Error fetching meal plans:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSearchResults = (results: any[]) => {
    // Extract meal plans from homemaker results
    const allPlans: any[] = [];
    results.forEach(homemaker => {
      homemaker.meal_plans
        .filter((plan: any) => plan.is_available)
        .forEach((plan: any) => {
          allPlans.push({
            ...plan,
            homemaker_profiles: {
              id: homemaker.id,
              business_name: homemaker.business_name,
              rating: homemaker.rating,
              total_reviews: homemaker.total_reviews,
              is_active: homemaker.is_active,
              verification_status: homemaker.verification_status,
              profiles: homemaker.profiles
            }
          });
        });
    });
    setFilteredPlans(allPlans);
  };

  const handleOrderNow = (plan: any) => {
    if (!user) {
      navigate('/auth');
      return;
    }
    setSelectedPlan(plan);
  };

  const applyMealTypeFilter = (plans: any[]) => {
    if (filter === 'all') return plans;
    return plans.filter((plan: any) => plan.meal_type === filter);
  };

  const displayedPlans = applyMealTypeFilter(filteredPlans);
  const selectedChef = searchParams.get('chef');

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-orange-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-orange-50 to-yellow-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            {selectedChef ? "Chef's Meal Plans" : "Available Meal Plans"}
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Choose from our verified home cooks and enjoy delicious, homemade meals delivered fresh to your door.
          </p>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search Component - Only show if not filtering by specific chef */}
        {!selectedChef && (
          <HomemakerSearch 
            onResults={handleSearchResults}
            onLoading={setSearchLoading}
          />
        )}

        {/* View Toggle */}
        <div className="flex flex-wrap gap-4 mb-8">
          <button
            onClick={() => setShowTodaySpecials(true)}
            className={`px-6 py-2 rounded-lg font-medium transition-colors flex items-center ${
              showTodaySpecials
                ? 'bg-orange-500 text-white'
                : 'bg-white text-gray-700 hover:bg-gray-100 border border-gray-200'
            }`}
          >
            <Calendar className="h-4 w-4 mr-2" />
            Today's Specials
          </button>
          <button
            onClick={() => setShowTodaySpecials(false)}
            className={`px-6 py-2 rounded-lg font-medium transition-colors flex items-center ${
              !showTodaySpecials
                ? 'bg-orange-500 text-white'
                : 'bg-white text-gray-700 hover:bg-gray-100 border border-gray-200'
            }`}
          >
            <ChefHat className="h-4 w-4 mr-2" />
            All Meal Plans
          </button>
        </div>

        {showTodaySpecials ? (
          <div className="bg-white rounded-lg shadow-lg p-6 text-center">
            <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Today's Specials Coming Soon!</h3>
            <p className="text-gray-600 mb-4">
              We're working on bringing you daily special menus from our home cooks.
            </p>
            <button
              onClick={() => setShowTodaySpecials(false)}
              className="bg-orange-500 text-white px-6 py-2 rounded-lg hover:bg-orange-600 transition-colors"
            >
              View All Meal Plans
            </button>
          </div>
        ) : (
          <>
            {/* Loading State */}
            {searchLoading && (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500 mx-auto"></div>
                <p className="text-gray-600 mt-4">Searching meal plans...</p>
              </div>
            )}

            {/* Results Summary */}
            {!searchLoading && (
              <div className="mb-6 flex justify-between items-center">
                <p className="text-gray-600">
                  Showing {displayedPlans.length} meal plans
                  {selectedChef && " from selected chef"}
                </p>
                
                {/* Meal Type Filters */}
                <div className="flex gap-2">
                  {['all', 'breakfast', 'lunch', 'dinner', 'full_day'].map((type) => (
                    <button
                      key={type}
                      onClick={() => setFilter(type)}
                      className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                        filter === type
                          ? 'bg-orange-500 text-white'
                          : 'bg-white text-gray-700 hover:bg-gray-100 border border-gray-200'
                      }`}
                    >
                      {type === 'all' ? 'All' : type.charAt(0).toUpperCase() + type.slice(1).replace('_', ' ')}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Meal Plans Grid */}
            {!searchLoading && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {displayedPlans.map((plan: any) => (
                  <div key={plan.id} className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
                    <div className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center">
                          <ChefHat className="h-5 w-5 text-orange-500 mr-2" />
                          <h3 className="font-semibold text-gray-900">
                            {plan.homemaker_profiles.business_name}
                          </h3>
                        </div>
                        <div className="flex items-center">
                          <Star className="h-4 w-4 text-yellow-400 fill-current" />
                          <span className="text-sm text-gray-600 ml-1">
                            {plan.homemaker_profiles.rating ? plan.homemaker_profiles.rating.toFixed(1) : 'New'}
                          </span>
                        </div>
                      </div>

                      <h4 className="text-lg font-semibold text-gray-900 mb-2">{plan.name}</h4>
                      <p className="text-gray-600 mb-4 line-clamp-3">{plan.description}</p>

                      <div className="flex items-center text-sm text-gray-500 mb-2">
                        <Clock className="h-4 w-4 mr-1" />
                        <span className="capitalize">{plan.meal_type.replace('_', ' ')}</span>
                      </div>

                      <div className="flex items-center text-sm text-gray-500 mb-4">
                        <MapPin className="h-4 w-4 mr-1" />
                        <span>{plan.homemaker_profiles.profiles.address || 'Location available on order'}</span>
                      </div>

                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <span className="text-2xl font-bold text-gray-900">₹{plan.price_per_day}</span>
                          <span className="text-gray-600">/day</span>
                        </div>
                        <button
                          onClick={() => handleOrderNow(plan)}
                          className="bg-orange-500 text-white px-6 py-2 rounded-lg hover:bg-orange-600 transition-colors font-medium flex items-center"
                        >
                          <ShoppingCart className="h-4 w-4 mr-2" />
                          Order Now
                        </button>
                      </div>

                      {plan.homemaker_profiles.total_reviews > 0 && (
                        <div className="pt-4 border-t border-gray-200">
                          <p className="text-sm text-gray-600">
                            {plan.homemaker_profiles.total_reviews} reviews • by {plan.homemaker_profiles.profiles.full_name}
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* No Results */}
            {!searchLoading && displayedPlans.length === 0 && (
              <div className="text-center py-12">
                <ChefHat className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-medium text-gray-900 mb-2">No meal plans found</h3>
                <p className="text-gray-600 mb-4">
                  {selectedChef 
                    ? "This chef doesn't have any available meal plans matching your criteria."
                    : "Try adjusting your search criteria or browse all available chefs."
                  }
                </p>
                <button
                  onClick={() => navigate('/chefs')}
                  className="bg-orange-500 text-white px-6 py-2 rounded-lg hover:bg-orange-600 transition-colors"
                >
                  Browse All Chefs
                </button>
              </div>
            )}
          </>
        )}
      </div>

      {/* Order Modal */}
      <OrderModal
        isOpen={!!selectedPlan}
        onClose={() => setSelectedPlan(null)}
        mealPlan={selectedPlan}
      />

      <Footer />
    </div>
  );
};

export default MealPlansPage;