import { createClient } from '@supabase/supabase-js';

// Use environment variables with fallback to direct values
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://tbhjynrpngypocfrbyzj.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRiaGp5bnJwbmd5cG9jZnJieXpqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTEwMzgyMTksImV4cCI6MjA2NjYxNDIxOX0.SjhjphKsp5eNFHJo-HnW83eX2wZTLEw1vum22V9t0rY';

// Create Supabase client with better configuration
export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true,
    flowType: 'pkce'
  },
  realtime: {
    params: {
      eventsPerSecond: 10
    }
  },
  global: {
    headers: {
      'x-my-custom-header': 'mealnest-app'
    }
  }
});

// Test connection function
export const testConnection = async () => {
  try {
    const { data, error } = await supabase.from('profiles').select('count').limit(1);
    if (error) {
      console.error('Supabase connection error:', error);
      return false;
    }
    console.log('Supabase connection successful');
    return true;
  } catch (error) {
    console.error('Supabase connection failed:', error);
    return false;
  }
};

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          email: string;
          full_name: string;
          user_type: 'customer' | 'homemaker';
          phone: string | null;
          address: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          email: string;
          full_name: string;
          user_type: 'customer' | 'homemaker';
          phone?: string | null;
          address?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          email?: string;
          full_name?: string;
          user_type?: 'customer' | 'homemaker';
          phone?: string | null;
          address?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      customer_accounts: {
        Row: {
          id: string;
          user_id: string;
          username: string | null;
          display_name: string;
          email: string;
          phone: string | null;
          profile_image_url: string | null;
          bio: string | null;
          date_of_birth: string | null;
          gender: string | null;
          is_verified: boolean;
          account_status: string;
          total_orders: number;
          total_spent: number;
          loyalty_points: number;
          preferred_cuisine: string[];
          dietary_restrictions: string[];
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          username?: string | null;
          display_name: string;
          email: string;
          phone?: string | null;
          profile_image_url?: string | null;
          bio?: string | null;
          date_of_birth?: string | null;
          gender?: string | null;
          is_verified?: boolean;
          account_status?: string;
          total_orders?: number;
          total_spent?: number;
          loyalty_points?: number;
          preferred_cuisine?: string[];
          dietary_restrictions?: string[];
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          username?: string | null;
          display_name?: string;
          email?: string;
          phone?: string | null;
          profile_image_url?: string | null;
          bio?: string | null;
          date_of_birth?: string | null;
          gender?: string | null;
          is_verified?: boolean;
          account_status?: string;
          total_orders?: number;
          total_spent?: number;
          loyalty_points?: number;
          preferred_cuisine?: string[];
          dietary_restrictions?: string[];
          created_at?: string;
          updated_at?: string;
        };
      };
      homemaker_accounts: {
        Row: {
          id: string;
          user_id: string;
          username: string | null;
          business_name: string;
          display_name: string;
          email: string;
          phone: string;
          profile_image_url: string | null;
          cover_image_url: string | null;
          bio: string | null;
          business_description: string;
          specialties: string[];
          cuisine_types: string[];
          experience_years: number;
          certifications: string[];
          rating: number;
          total_reviews: number;
          total_orders: number;
          is_verified: boolean;
          verification_status: string;
          is_active: boolean;
          account_status: string;
          business_license: string | null;
          fssai_license: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          username?: string | null;
          business_name: string;
          display_name: string;
          email: string;
          phone: string;
          profile_image_url?: string | null;
          cover_image_url?: string | null;
          bio?: string | null;
          business_description: string;
          specialties?: string[];
          cuisine_types?: string[];
          experience_years?: number;
          certifications?: string[];
          rating?: number;
          total_reviews?: number;
          total_orders?: number;
          is_verified?: boolean;
          verification_status?: string;
          is_active?: boolean;
          account_status?: string;
          business_license?: string | null;
          fssai_license?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          username?: string | null;
          business_name?: string;
          display_name?: string;
          email?: string;
          phone?: string;
          profile_image_url?: string | null;
          cover_image_url?: string | null;
          bio?: string | null;
          business_description?: string;
          specialties?: string[];
          cuisine_types?: string[];
          experience_years?: number;
          certifications?: string[];
          rating?: number;
          total_reviews?: number;
          total_orders?: number;
          is_verified?: boolean;
          verification_status?: string;
          is_active?: boolean;
          account_status?: string;
          business_license?: string | null;
          fssai_license?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      homemaker_profiles: {
        Row: {
          id: string;
          user_id: string;
          business_name: string;
          description: string;
          specialties: string[];
          rating: number;
          total_reviews: number;
          is_active: boolean;
          verification_status: 'pending' | 'verified' | 'rejected';
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          business_name: string;
          description: string;
          specialties: string[];
          rating?: number;
          total_reviews?: number;
          is_active?: boolean;
          verification_status?: 'pending' | 'verified' | 'rejected';
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          business_name?: string;
          description?: string;
          specialties?: string[];
          rating?: number;
          total_reviews?: number;
          is_active?: boolean;
          verification_status?: 'pending' | 'verified' | 'rejected';
          created_at?: string;
          updated_at?: string;
        };
      };
      meal_plans: {
        Row: {
          id: string;
          homemaker_id: string;
          name: string;
          description: string;
          price_per_day: number;
          meal_type: 'breakfast' | 'lunch' | 'dinner' | 'full_day';
          is_available: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          homemaker_id: string;
          name: string;
          description: string;
          price_per_day: number;
          meal_type: 'breakfast' | 'lunch' | 'dinner' | 'full_day';
          is_available?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          homemaker_id?: string;
          name?: string;
          description?: string;
          price_per_day?: number;
          meal_type?: 'breakfast' | 'lunch' | 'dinner' | 'full_day';
          is_available?: boolean;
          created_at?: string;
          updated_at?: string;
        };
      };
      subscriptions: {
        Row: {
          id: string;
          customer_id: string;
          meal_plan_id: string;
          start_date: string;
          end_date: string;
          status: 'active' | 'paused' | 'cancelled';
          subscription_type: 'monthly' | 'quarterly' | 'yearly';
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          customer_id: string;
          meal_plan_id: string;
          start_date: string;
          end_date: string;
          status?: 'active' | 'paused' | 'cancelled';
          subscription_type: 'monthly' | 'quarterly' | 'yearly';
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          customer_id?: string;
          meal_plan_id?: string;
          start_date?: string;
          end_date?: string;
          status?: 'active' | 'paused' | 'cancelled';
          subscription_type?: 'monthly' | 'quarterly' | 'yearly';
          created_at?: string;
          updated_at?: string;
        };
      };
      reviews: {
        Row: {
          id: string;
          customer_id: string;
          homemaker_id: string;
          subscription_id: string;
          rating: number;
          comment: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          customer_id: string;
          homemaker_id: string;
          subscription_id: string;
          rating: number;
          comment: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          customer_id?: string;
          homemaker_id?: string;
          subscription_id?: string;
          rating?: number;
          comment?: string;
          created_at?: string;
          updated_at?: string;
        };
      };
      daily_reports: {
        Row: {
          id: string;
          homemaker_id: string;
          report_date: string;
          full_day_recipes: string[];
          instant_recipes: string[];
          breakfast_specialties: string[];
          lunch_specialties: string[];
          dinner_specialties: string[];
          is_active: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          homemaker_id: string;
          report_date: string;
          full_day_recipes?: string[];
          instant_recipes?: string[];
          breakfast_specialties?: string[];
          lunch_specialties?: string[];
          dinner_specialties?: string[];
          is_active?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          homemaker_id?: string;
          report_date?: string;
          full_day_recipes?: string[];
          instant_recipes?: string[];
          breakfast_specialties?: string[];
          lunch_specialties?: string[];
          dinner_specialties?: string[];
          is_active?: boolean;
          created_at?: string;
          updated_at?: string;
        };
      };
      customer_addresses: {
        Row: {
          id: string;
          customer_id: string;
          address_type: string;
          address_line_1: string;
          address_line_2: string | null;
          city: string;
          state: string;
          postal_code: string;
          landmark: string | null;
          delivery_instructions: string | null;
          is_default: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          customer_id: string;
          address_type?: string;
          address_line_1: string;
          address_line_2?: string | null;
          city: string;
          state: string;
          postal_code: string;
          landmark?: string | null;
          delivery_instructions?: string | null;
          is_default?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          customer_id?: string;
          address_type?: string;
          address_line_1?: string;
          address_line_2?: string | null;
          city?: string;
          state?: string;
          postal_code?: string;
          landmark?: string | null;
          delivery_instructions?: string | null;
          is_default?: boolean;
          created_at?: string;
          updated_at?: string;
        };
      };
    };
  };
};