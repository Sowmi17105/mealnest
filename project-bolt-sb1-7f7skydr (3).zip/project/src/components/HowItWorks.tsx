import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Calendar, Truck } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

const HowItWorks = () => {
  const navigate = useNavigate();
  const { user } = useAuth();

  const handleGetStarted = () => {
    if (user) {
      navigate('/meal-plans');
    } else {
      navigate('/auth');
    }
  };

  const steps = [
    {
      icon: Search,
      title: 'Choose Your Plan',
      description: 'Select from breakfast, lunch, or supper plans. Customize based on your dietary preferences and schedule.',
      image: 'https://images.pexels.com/photos/1640773/pexels-photo-1640773.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      icon: Calendar,
      title: 'Set Your Schedule',
      description: 'Pick your delivery times and days. Subscribe monthly, quarterly, or yearly for the best value.',
      image: 'https://images.pexels.com/photos/4551832/pexels-photo-4551832.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      icon: Truck,
      title: 'Enjoy Fresh Meals',
      description: 'Receive hot, homemade meals delivered right to your door. No cooking, no cleanup, just delicious food.',
      image: 'https://images.pexels.com/photos/4393021/pexels-photo-4393021.jpeg?auto=compress&cs=tinysrgb&w=400'
    }
  ];

  return (
    <section id="how-it-works" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            How It Works
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Getting started with Mealnest is as easy as 1-2-3. 
            Just three simple steps to transform your mealtime experience.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {steps.map((step, index) => (
            <div key={index} className="relative">
              {/* Step Number */}
              <div className="absolute -top-4 left-8 bg-orange-500 text-white w-8 h-8 rounded-full flex items-center justify-center font-bold z-10">
                {index + 1}
              </div>

              <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300">
                <div className="h-48 overflow-hidden">
                  <img 
                    src={step.image} 
                    alt={step.title}
                    className="w-full h-full object-cover transform hover:scale-105 transition-transform duration-300"
                  />
                </div>
                
                <div className="p-8">
                  <div className="flex items-center mb-4">
                    <div className="bg-orange-100 p-3 rounded-lg mr-4">
                      <step.icon className="h-6 w-6 text-orange-600" />
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900">
                      {step.title}
                    </h3>
                  </div>
                  <p className="text-gray-600 leading-relaxed">
                    {step.description}
                  </p>
                </div>
              </div>

              {/* Connector Line */}
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-1/2 -right-6 w-12 h-0.5 bg-orange-200 z-0"></div>
              )}
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <button 
            onClick={handleGetStarted}
            className="bg-orange-500 text-white px-8 py-4 rounded-lg hover:bg-orange-600 transition-colors font-semibold text-lg"
          >
            {user ? 'Browse Meal Plans' : 'Get Started Today'}
          </button>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;