import React, { useState, useEffect } from 'react';
import { Search, MapPin, Star, Filter, X, ChefHat, Clock, Heart } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface HomemakerSearchProps {
  onResults: (results: any[]) => void;
  onLoading: (loading: boolean) => void;
}

const HomemakerSearch: React.FC<HomemakerSearchProps> = ({ onResults, onLoading }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({
    location: '',
    cuisineType: '',
    minRating: 0,
    maxPrice: 1000,
    minPrice: 0,
    sortBy: 'rating' // rating, price_low, price_high, newest
  });

  const cuisineTypes = [
    'North Indian', 'South Indian', 'Chinese', 'Continental', 
    'Italian', 'Mexican', 'Thai', 'Bengali', 'Gujarati', 
    'Punjabi', 'Maharashtrian', 'Rajasthani', 'Street Food'
  ];

  const sortOptions = [
    { value: 'rating', label: 'Highest Rated' },
    { value: 'price_low', label: 'Price: Low to High' },
    { value: 'price_high', label: 'Price: High to Low' },
    { value: 'newest', label: 'Newest First' }
  ];

  useEffect(() => {
    const delayedSearch = setTimeout(() => {
      if (searchQuery.length >= 2 || Object.values(filters).some(v => v !== '' && v !== 0)) {
        performSearch();
      } else if (searchQuery.length === 0) {
        // Show all homemakers when search is empty
        performSearch();
      }
    }, 300);

    return () => clearTimeout(delayedSearch);
  }, [searchQuery, filters]);

  const performSearch = async () => {
    onLoading(true);
    try {
      let query = supabase
        .from('homemaker_profiles')
        .select(`
          *,
          profiles (
            full_name,
            email,
            phone,
            address
          ),
          meal_plans (
            id,
            name,
            description,
            price_per_day,
            meal_type,
            is_available
          )
        `)
        .eq('is_active', true)
        .eq('verification_status', 'verified');

      // Text search in business name, description, and specialties
      if (searchQuery.trim()) {
        query = query.or(`business_name.ilike.%${searchQuery}%,description.ilike.%${searchQuery}%,specialties.cs.{${searchQuery}}`);
      }

      // Location filter
      if (filters.location.trim()) {
        query = query.or(`profiles.address.ilike.%${filters.location}%`);
      }

      // Rating filter
      if (filters.minRating > 0) {
        query = query.gte('rating', filters.minRating);
      }

      // Cuisine type filter (search in specialties array)
      if (filters.cuisineType) {
        query = query.contains('specialties', [filters.cuisineType]);
      }

      // Sorting
      switch (filters.sortBy) {
        case 'rating':
          query = query.order('rating', { ascending: false });
          break;
        case 'newest':
          query = query.order('created_at', { ascending: false });
          break;
        default:
          query = query.order('rating', { ascending: false });
      }

      const { data, error } = await query;

      if (error) throw error;

      let results = data || [];

      // Filter by price range (need to check meal plans)
      if (filters.minPrice > 0 || filters.maxPrice < 1000) {
        results = results.filter(homemaker => {
          const prices = homemaker.meal_plans
            .filter((plan: any) => plan.is_available)
            .map((plan: any) => plan.price_per_day);
          
          if (prices.length === 0) return false;
          
          const minPrice = Math.min(...prices);
          const maxPrice = Math.max(...prices);
          
          return minPrice >= filters.minPrice && maxPrice <= filters.maxPrice;
        });
      }

      // Sort by price if selected
      if (filters.sortBy === 'price_low' || filters.sortBy === 'price_high') {
        results.sort((a, b) => {
          const aPrices = a.meal_plans
            .filter((plan: any) => plan.is_available)
            .map((plan: any) => plan.price_per_day);
          const bPrices = b.meal_plans
            .filter((plan: any) => plan.is_available)
            .map((plan: any) => plan.price_per_day);
          
          const aMinPrice = aPrices.length > 0 ? Math.min(...aPrices) : 0;
          const bMinPrice = bPrices.length > 0 ? Math.min(...bPrices) : 0;
          
          return filters.sortBy === 'price_low' 
            ? aMinPrice - bMinPrice 
            : bMinPrice - aMinPrice;
        });
      }

      onResults(results);
    } catch (error) {
      console.error('Search error:', error);
      onResults([]);
    } finally {
      onLoading(false);
    }
  };

  const clearFilters = () => {
    setFilters({
      location: '',
      cuisineType: '',
      minRating: 0,
      maxPrice: 1000,
      minPrice: 0,
      sortBy: 'rating'
    });
    setSearchQuery('');
  };

  const activeFiltersCount = Object.values(filters).filter(v => 
    v !== '' && v !== 0 && v !== 'rating' && v !== 1000
  ).length;

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
      {/* Main Search Bar */}
      <div className="flex flex-col lg:flex-row gap-4 mb-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
          <input
            type="text"
            placeholder="Search by chef name, cuisine, or specialty..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
          />
        </div>
        
        <button
          onClick={() => setShowFilters(!showFilters)}
          className={`flex items-center px-6 py-3 rounded-lg font-medium transition-colors ${
            showFilters || activeFiltersCount > 0
              ? 'bg-orange-500 text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          <Filter className="h-5 w-5 mr-2" />
          Filters
          {activeFiltersCount > 0 && (
            <span className="ml-2 bg-white text-orange-500 rounded-full px-2 py-1 text-xs font-bold">
              {activeFiltersCount}
            </span>
          )}
        </button>
      </div>

      {/* Advanced Filters */}
      {showFilters && (
        <div className="border-t border-gray-200 pt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Location Filter */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <MapPin className="inline h-4 w-4 mr-1" />
                Location
              </label>
              <input
                type="text"
                placeholder="Enter city or area"
                value={filters.location}
                onChange={(e) => setFilters({ ...filters, location: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
              />
            </div>

            {/* Cuisine Type Filter */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <ChefHat className="inline h-4 w-4 mr-1" />
                Cuisine Type
              </label>
              <select
                value={filters.cuisineType}
                onChange={(e) => setFilters({ ...filters, cuisineType: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
              >
                <option value="">All Cuisines</option>
                {cuisineTypes.map(cuisine => (
                  <option key={cuisine} value={cuisine}>{cuisine}</option>
                ))}
              </select>
            </div>

            {/* Rating Filter */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Star className="inline h-4 w-4 mr-1" />
                Minimum Rating
              </label>
              <select
                value={filters.minRating}
                onChange={(e) => setFilters({ ...filters, minRating: Number(e.target.value) })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
              >
                <option value={0}>Any Rating</option>
                <option value={3}>3+ Stars</option>
                <option value={4}>4+ Stars</option>
                <option value={4.5}>4.5+ Stars</option>
              </select>
            </div>

            {/* Sort By */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Clock className="inline h-4 w-4 mr-1" />
                Sort By
              </label>
              <select
                value={filters.sortBy}
                onChange={(e) => setFilters({ ...filters, sortBy: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
              >
                {sortOptions.map(option => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Price Range */}
          <div className="mt-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Price Range (₹ per day)
            </label>
            <div className="flex items-center space-x-4">
              <div className="flex-1">
                <input
                  type="range"
                  min="0"
                  max="1000"
                  step="50"
                  value={filters.minPrice}
                  onChange={(e) => setFilters({ ...filters, minPrice: Number(e.target.value) })}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>₹{filters.minPrice}</span>
                  <span>Min</span>
                </div>
              </div>
              <span className="text-gray-500">to</span>
              <div className="flex-1">
                <input
                  type="range"
                  min="0"
                  max="1000"
                  step="50"
                  value={filters.maxPrice}
                  onChange={(e) => setFilters({ ...filters, maxPrice: Number(e.target.value) })}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>₹{filters.maxPrice}</span>
                  <span>Max</span>
                </div>
              </div>
            </div>
          </div>

          {/* Clear Filters */}
          {activeFiltersCount > 0 && (
            <div className="mt-6 flex justify-end">
              <button
                onClick={clearFilters}
                className="flex items-center px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors"
              >
                <X className="h-4 w-4 mr-2" />
                Clear All Filters
              </button>
            </div>
          )}
        </div>
      )}

      {/* Search Suggestions */}
      {searchQuery.length === 0 && !showFilters && (
        <div className="mt-4">
          <p className="text-sm text-gray-500 mb-2">Popular searches:</p>
          <div className="flex flex-wrap gap-2">
            {['North Indian', 'South Indian', 'Breakfast', 'Lunch', 'Dinner'].map(suggestion => (
              <button
                key={suggestion}
                onClick={() => setSearchQuery(suggestion)}
                className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm hover:bg-orange-100 hover:text-orange-700 transition-colors"
              >
                {suggestion}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default HomemakerSearch;