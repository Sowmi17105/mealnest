import React, { useState, useEffect } from 'react';
import { X, Calendar, ChefHat, Clock, Utensils, Save } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';

interface DailyReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: () => void;
  homemakerId: string;
}

const DailyReportModal: React.FC<DailyReportModalProps> = ({ 
  isOpen, 
  onClose, 
  onSave, 
  homemakerId 
}) => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [reportData, setReportData] = useState({
    reportDate: new Date().toISOString().split('T')[0],
    fullDayRecipes: [''],
    instantRecipes: [''],
    breakfastSpecialties: [''],
    lunchSpecialties: [''],
    dinnerSpecialties: [''],
  });

  useEffect(() => {
    if (isOpen) {
      fetchTodayReport();
    }
  }, [isOpen, homemakerId]);

  const fetchTodayReport = async () => {
    try {
      const today = new Date().toISOString().split('T')[0];
      const { data, error } = await supabase
        .from('daily_reports')
        .select('*')
        .eq('homemaker_id', homemakerId)
        .eq('report_date', today)
        .single();

      if (data) {
        setReportData({
          reportDate: data.report_date,
          fullDayRecipes: data.full_day_recipes.length > 0 ? data.full_day_recipes : [''],
          instantRecipes: data.instant_recipes.length > 0 ? data.instant_recipes : [''],
          breakfastSpecialties: data.breakfast_specialties.length > 0 ? data.breakfast_specialties : [''],
          lunchSpecialties: data.lunch_specialties.length > 0 ? data.lunch_specialties : [''],
          dinnerSpecialties: data.dinner_specialties.length > 0 ? data.dinner_specialties : [''],
        });
      }
    } catch (error) {
      console.error('Error fetching today report:', error);
    }
  };

  const handleArrayChange = (field: string, index: number, value: string) => {
    setReportData(prev => ({
      ...prev,
      [field]: prev[field as keyof typeof prev].map((item: string, i: number) => 
        i === index ? value : item
      )
    }));
  };

  const addArrayItem = (field: string) => {
    setReportData(prev => ({
      ...prev,
      [field]: [...prev[field as keyof typeof prev], '']
    }));
  };

  const removeArrayItem = (field: string, index: number) => {
    setReportData(prev => ({
      ...prev,
      [field]: prev[field as keyof typeof prev].filter((_: string, i: number) => i !== index)
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    setLoading(true);
    try {
      const reportPayload = {
        homemaker_id: homemakerId,
        report_date: reportData.reportDate,
        full_day_recipes: reportData.fullDayRecipes.filter(item => item.trim() !== ''),
        instant_recipes: reportData.instantRecipes.filter(item => item.trim() !== ''),
        breakfast_specialties: reportData.breakfastSpecialties.filter(item => item.trim() !== ''),
        lunch_specialties: reportData.lunchSpecialties.filter(item => item.trim() !== ''),
        dinner_specialties: reportData.dinnerSpecialties.filter(item => item.trim() !== ''),
        is_active: true,
      };

      const { error } = await supabase
        .from('daily_reports')
        .upsert(reportPayload, {
          onConflict: 'homemaker_id,report_date'
        });

      if (error) throw error;

      alert('Daily report saved successfully!');
      onSave();
      onClose();
    } catch (error: any) {
      alert('Error saving report: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  const renderArrayInput = (
    title: string, 
    field: string, 
    icon: React.ReactNode, 
    placeholder: string
  ) => (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-2">
        {icon}
        {title}
      </label>
      <div className="space-y-2">
        {reportData[field as keyof typeof reportData].map((item: string, index: number) => (
          <div key={index} className="flex gap-2">
            <input
              type="text"
              value={item}
              onChange={(e) => handleArrayChange(field, index, e.target.value)}
              className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
              placeholder={placeholder}
            />
            {reportData[field as keyof typeof reportData].length > 1 && (
              <button
                type="button"
                onClick={() => removeArrayItem(field, index)}
                className="px-3 py-2 text-red-600 hover:bg-red-50 rounded-lg"
              >
                ×
              </button>
            )}
          </div>
        ))}
        <button
          type="button"
          onClick={() => addArrayItem(field)}
          className="text-orange-600 hover:text-orange-700 text-sm font-medium"
        >
          + Add another
        </button>
      </div>
    </div>
  );

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center p-6 border-b">
          <h2 className="text-2xl font-bold text-gray-900">Daily Cooking Report</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="h-6 w-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Date */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Calendar className="inline h-4 w-4 mr-1" />
              Report Date
            </label>
            <input
              type="date"
              required
              value={reportData.reportDate}
              onChange={(e) => setReportData({ ...reportData, reportDate: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Full Day Recipes */}
            {renderArrayInput(
              'Full Day Recipes',
              'fullDayRecipes',
              <ChefHat className="inline h-4 w-4 mr-1" />,
              'Enter full day recipe (e.g., North Indian Thali)'
            )}

            {/* Instant Recipes */}
            {renderArrayInput(
              'Instant Recipes',
              'instantRecipes',
              <Clock className="inline h-4 w-4 mr-1" />,
              'Enter instant recipe (e.g., Maggi, Sandwich)'
            )}

            {/* Breakfast Specialties */}
            {renderArrayInput(
              'Breakfast Specialties',
              'breakfastSpecialties',
              <Utensils className="inline h-4 w-4 mr-1" />,
              'Enter breakfast specialty (e.g., Poha, Upma)'
            )}

            {/* Lunch Specialties */}
            {renderArrayInput(
              'Lunch Specialties',
              'lunchSpecialties',
              <Utensils className="inline h-4 w-4 mr-1" />,
              'Enter lunch specialty (e.g., Biryani, Dal Rice)'
            )}

            {/* Dinner Specialties */}
            {renderArrayInput(
              'Dinner Specialties',
              'dinnerSpecialties',
              <Utensils className="inline h-4 w-4 mr-1" />,
              'Enter dinner specialty (e.g., Roti Sabzi, Pulao)'
            )}
          </div>

          {/* Submit Button */}
          <div className="flex space-x-4 pt-6 border-t">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex-1 bg-orange-500 text-white px-6 py-3 rounded-lg hover:bg-orange-600 transition-colors font-semibold flex items-center justify-center disabled:opacity-50"
            >
              {loading ? (
                'Saving...'
              ) : (
                <>
                  <Save className="h-5 w-5 mr-2" />
                  Save Report
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default DailyReportModal;