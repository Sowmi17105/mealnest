import React, { useState, useEffect } from 'react';
import { ChefHat, Clock, Utensils, Calendar, Star } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface TodaySpecialsProps {
  selectedChef?: string;
}

const TodaySpecials: React.FC<TodaySpecialsProps> = ({ selectedChef }) => {
  const [dailyReports, setDailyReports] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchTodayReports();
  }, [selectedChef]);

  const fetchTodayReports = async () => {
    try {
      const today = new Date().toISOString().split('T')[0];
      
      let query = supabase
        .from('daily_reports')
        .select(`
          *,
          homemaker_profiles (
            id,
            business_name,
            rating,
            profiles (
              full_name,
              address
            )
          )
        `)
        .eq('report_date', today)
        .eq('is_active', true);

      if (selectedChef) {
        query = query.eq('homemaker_id', selectedChef);
      }

      const { data, error } = await query.order('created_at', { ascending: false });

      if (error) throw error;
      setDailyReports(data || []);
    } catch (error) {
      console.error('Error fetching today reports:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-6 bg-gray-200 rounded w-1/3"></div>
          <div className="space-y-3">
            <div className="h-4 bg-gray-200 rounded"></div>
            <div className="h-4 bg-gray-200 rounded w-5/6"></div>
          </div>
        </div>
      </div>
    );
  }

  if (dailyReports.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-lg p-6 text-center">
        <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 mb-2">No Reports Today</h3>
        <p className="text-gray-600">
          {selectedChef 
            ? "This chef hasn't posted today's menu yet." 
            : "No chefs have posted their daily menus yet."
          }
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Today's Specials</h2>
        <p className="text-gray-600">Fresh menus from our home cooks for {new Date().toLocaleDateString()}</p>
      </div>

      {dailyReports.map((report: any) => (
        <div key={report.id} className="bg-white rounded-lg shadow-lg overflow-hidden">
          {/* Chef Header */}
          <div className="bg-orange-50 px-6 py-4 border-b">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="bg-orange-100 p-2 rounded-full mr-3">
                  <ChefHat className="h-6 w-6 text-orange-600" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">
                    {report.homemaker_profiles.business_name}
                  </h3>
                  <p className="text-sm text-gray-600">
                    by {report.homemaker_profiles.profiles.full_name}
                  </p>
                </div>
              </div>
              <div className="flex items-center">
                <Star className="h-4 w-4 text-yellow-400 fill-current mr-1" />
                <span className="text-sm text-gray-600">
                  {report.homemaker_profiles.rating ? report.homemaker_profiles.rating.toFixed(1) : 'New'}
                </span>
              </div>
            </div>
          </div>

          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {/* Full Day Recipes */}
              {report.full_day_recipes.length > 0 && (
                <div>
                  <h4 className="flex items-center text-sm font-semibold text-gray-900 mb-3">
                    <ChefHat className="h-4 w-4 mr-2 text-orange-500" />
                    Full Day Recipes
                  </h4>
                  <ul className="space-y-2">
                    {report.full_day_recipes.map((recipe: string, index: number) => (
                      <li key={index} className="text-sm text-gray-700 bg-gray-50 px-3 py-2 rounded-lg">
                        {recipe}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Instant Recipes */}
              {report.instant_recipes.length > 0 && (
                <div>
                  <h4 className="flex items-center text-sm font-semibold text-gray-900 mb-3">
                    <Clock className="h-4 w-4 mr-2 text-green-500" />
                    Instant Recipes
                  </h4>
                  <ul className="space-y-2">
                    {report.instant_recipes.map((recipe: string, index: number) => (
                      <li key={index} className="text-sm text-gray-700 bg-green-50 px-3 py-2 rounded-lg">
                        {recipe}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Breakfast Specialties */}
              {report.breakfast_specialties.length > 0 && (
                <div>
                  <h4 className="flex items-center text-sm font-semibold text-gray-900 mb-3">
                    <Utensils className="h-4 w-4 mr-2 text-yellow-500" />
                    Breakfast Specialties
                  </h4>
                  <ul className="space-y-2">
                    {report.breakfast_specialties.map((recipe: string, index: number) => (
                      <li key={index} className="text-sm text-gray-700 bg-yellow-50 px-3 py-2 rounded-lg">
                        {recipe}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Lunch Specialties */}
              {report.lunch_specialties.length > 0 && (
                <div>
                  <h4 className="flex items-center text-sm font-semibold text-gray-900 mb-3">
                    <Utensils className="h-4 w-4 mr-2 text-blue-500" />
                    Lunch Specialties
                  </h4>
                  <ul className="space-y-2">
                    {report.lunch_specialties.map((recipe: string, index: number) => (
                      <li key={index} className="text-sm text-gray-700 bg-blue-50 px-3 py-2 rounded-lg">
                        {recipe}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Dinner Specialties */}
              {report.dinner_specialties.length > 0 && (
                <div>
                  <h4 className="flex items-center text-sm font-semibold text-gray-900 mb-3">
                    <Utensils className="h-4 w-4 mr-2 text-purple-500" />
                    Dinner Specialties
                  </h4>
                  <ul className="space-y-2">
                    {report.dinner_specialties.map((recipe: string, index: number) => (
                      <li key={index} className="text-sm text-gray-700 bg-purple-50 px-3 py-2 rounded-lg">
                        {recipe}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            {/* Contact Info */}
            <div className="mt-6 pt-4 border-t border-gray-200">
              <p className="text-sm text-gray-600">
                📍 {report.homemaker_profiles.profiles.address || 'Location available on order'}
              </p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default TodaySpecials;