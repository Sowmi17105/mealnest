import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Check, Star, Clock, Heart, Users, Calendar } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

const MealPlans = () => {
  const navigate = useNavigate();
  const { user, userProfile } = useAuth();

  const handleSelectPlan = () => {
    console.log('Select Plan clicked', { user, userProfile });
    
    if (user && userProfile) {
      // User is authenticated, go to meal plans page
      navigate('/meal-plans');
    } else {
      // User not authenticated, go to auth page
      navigate('/auth');
    }
  };

  const handleStartFreeTrial = () => {
    console.log('Start Free Trial clicked', { user, userProfile });
    
    if (user && userProfile) {
      // User is authenticated, go to meal plans page
      navigate('/meal-plans');
    } else {
      // User not authenticated, go to auth page
      navigate('/auth');
    }
  };

  const handleContactUs = () => {
    navigate('/contact');
  };

  const plans = [
    {
      name: 'Breakfast Only',
      price: '₹99',
      period: 'per day',
      popular: false,
      description: 'Start your day right with nutritious breakfast delivered fresh to fuel your morning',
      features: [
        'Fresh breakfast daily',
        'Delivered by 9 AM',
        'Customizable preferences',
        'Weekend included',
        'No cooking required',
        'Perfect for busy mornings'
      ],
      color: 'border-gray-200',
      icon: '🌅',
      idealFor: 'Students, Early Workers'
    },
    {
      name: 'Lunch Special',
      price: '₹149',
      period: 'per day',
      popular: true,
      description: 'Perfect for office-goers and students who need a hearty, satisfying lunch',
      features: [
        'Complete lunch meals',
        'Office/hostel delivery',
        'Ready by 12-2 PM',
        'Variety of cuisines',
        'Healthy & filling',
        'Weekend delivery available'
      ],
      color: 'border-orange-500',
      icon: '🍽️',
      idealFor: 'Professionals, Students'
    },
    {
      name: 'Full Day Care',
      price: '₹299',
      period: 'per day',
      popular: false,
      description: 'Complete meal solution - breakfast, lunch, and supper for total peace of mind',
      features: [
        'All three meals included',
        'Flexible delivery times',
        'Maximum variety',
        'Best value for money',
        'Family portions available',
        'Custom dietary needs'
      ],
      color: 'border-gray-200',
      icon: '🏠',
      idealFor: 'Families, Elderly'
    }
  ];

  const subscriptionOptions = [
    { 
      duration: 'Monthly', 
      discount: '5%', 
      savings: 'Save ₹150',
      description: 'Perfect for trying out',
      icon: '📅'
    },
    { 
      duration: 'Quarterly', 
      discount: '12%', 
      savings: 'Save ₹450',
      description: 'Most popular choice',
      icon: '📊'
    },
    { 
      duration: 'Yearly', 
      discount: '20%', 
      savings: 'Save ₹2000',
      description: 'Maximum savings',
      icon: '🎯'
    }
  ];

  return (
    <section id="plans" className="py-20 bg-gradient-to-br from-gray-50 to-orange-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Choose Your Meal Plan
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Flexible plans designed to fit your lifestyle and budget. 
            All meals are freshly prepared by our verified home cooks with love and care.
          </p>
        </div>

        {/* Meal Plans */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {plans.map((plan, index) => (
            <div 
              key={index}
              className={`bg-white rounded-2xl shadow-lg overflow-hidden border-2 ${plan.color} relative ${plan.popular ? 'transform scale-105 shadow-2xl' : ''} hover:shadow-xl transition-all duration-300`}
            >
              {plan.popular && (
                <div className="absolute top-0 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-orange-500 to-red-500 text-white px-6 py-2 rounded-b-lg text-sm font-semibold">
                  <Star className="inline h-4 w-4 mr-1" />
                  Most Popular
                </div>
              )}
              
              <div className="p-8">
                {/* Plan Header */}
                <div className="text-center mb-6">
                  <div className="text-4xl mb-2">{plan.icon}</div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">
                    {plan.name}
                  </h3>
                  <p className="text-sm text-orange-500 font-medium mb-2">
                    Ideal for {plan.idealFor}
                  </p>
                  <p className="text-gray-600 leading-relaxed">
                    {plan.description}
                  </p>
                </div>
                
                {/* Pricing */}
                <div className="text-center mb-6">
                  <div className="flex items-baseline justify-center">
                    <span className="text-4xl font-bold text-gray-900">{plan.price}</span>
                    <span className="text-gray-600 ml-2">{plan.period}</span>
                  </div>
                  <p className="text-sm text-gray-500 mt-1">Delivery included</p>
                </div>
                
                {/* Features */}
                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center">
                      <Check className="h-5 w-5 text-green-500 mr-3 flex-shrink-0" />
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>
                
                {/* CTA Button */}
                <button 
                  onClick={handleSelectPlan}
                  className={`w-full py-3 px-6 rounded-lg font-semibold transition-all duration-300 ${
                    plan.popular 
                      ? 'bg-gradient-to-r from-orange-500 to-red-500 text-white hover:from-orange-600 hover:to-red-600 shadow-lg' 
                      : 'bg-gray-100 text-gray-900 hover:bg-orange-100 hover:text-orange-700'
                  }`}
                >
                  {user && userProfile ? 'Select This Plan' : 'Sign Up to Select'}
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Subscription Discounts */}
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-12">
          <div className="text-center mb-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              Save More with Longer Subscriptions
            </h3>
            <p className="text-gray-600">
              The longer you subscribe, the more you save. All plans come with our satisfaction guarantee.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {subscriptionOptions.map((option, index) => (
              <div 
                key={index}
                className="border-2 border-gray-200 rounded-xl p-6 hover:border-orange-500 transition-all duration-300 cursor-pointer group hover:shadow-lg"
              >
                <div className="text-center">
                  <div className="text-3xl mb-3">{option.icon}</div>
                  <h4 className="text-lg font-semibold text-gray-900 mb-2">
                    {option.duration}
                  </h4>
                  <div className="text-2xl font-bold text-orange-500 mb-1">
                    {option.discount} OFF
                  </div>
                  <p className="text-sm text-green-600 font-medium mb-2">
                    {option.savings}
                  </p>
                  <p className="text-xs text-gray-500">
                    {option.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Special Features */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl p-8 text-white">
            <div className="flex items-center mb-4">
              <Users className="h-8 w-8 mr-3" />
              <h3 className="text-xl font-bold">Group Pre-booking</h3>
            </div>
            <p className="mb-4">
              Planning an office lunch or birthday party? Pre-book meals 24 hours in advance for any group size.
            </p>
            <ul className="space-y-2 text-sm opacity-90">
              <li>• Office team lunches</li>
              <li>• Hostel birthday parties</li>
              <li>• Family gatherings</li>
            </ul>
          </div>

          <div className="bg-gradient-to-r from-green-500 to-teal-600 rounded-2xl p-8 text-white">
            <div className="flex items-center mb-4">
              <Heart className="h-8 w-8 mr-3" />
              <h3 className="text-xl font-bold">Made with Love</h3>
            </div>
            <p className="mb-4">
              Every meal is prepared by caring homemakers who put love and attention into each dish.
            </p>
            <ul className="space-y-2 text-sm opacity-90">
              <li>• Verified home cooks</li>
              <li>• Quality ingredients</li>
              <li>• Traditional recipes</li>
            </ul>
          </div>
        </div>

        {/* Final CTA */}
        <div className="text-center">
          <p className="text-gray-600 mb-6 text-lg">
            Not sure which plan is right for you? Try our 3-day free trial with any plan.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button 
              onClick={handleStartFreeTrial}
              className="bg-green-500 text-white px-8 py-4 rounded-lg hover:bg-green-600 transition-colors font-semibold text-lg shadow-lg transform hover:scale-105"
            >
              {user && userProfile ? 'Start 3-Day Free Trial' : 'Sign Up for Free Trial'}
            </button>
            <button 
              onClick={handleContactUs}
              className="border-2 border-gray-300 text-gray-700 px-8 py-4 rounded-lg hover:border-orange-500 hover:text-orange-500 transition-colors font-semibold"
            >
              Have Questions? Contact Us
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default MealPlans;