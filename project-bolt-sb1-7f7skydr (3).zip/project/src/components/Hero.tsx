import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, Star, Users, Clock, Heart } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

const Hero = () => {
  const navigate = useNavigate();
  const { user, userProfile } = useAuth();

  const handleStartSubscription = () => {
    console.log('Start Subscription clicked', { user, userProfile });
    
    if (user && userProfile) {
      // User is authenticated, go to meal plans
      navigate('/meal-plans');
    } else {
      // User not authenticated, go to auth page
      navigate('/auth');
    }
  };

  const handleViewMenu = () => {
    navigate('/meal-plans');
  };

  const handleJoinAsCook = () => {
    navigate('/auth');
  };

  return (
    <section className="bg-gradient-to-br from-orange-50 via-yellow-50 to-red-50 py-20 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-10 left-10 w-20 h-20 bg-orange-300 rounded-full"></div>
        <div className="absolute top-32 right-20 w-16 h-16 bg-yellow-300 rounded-full"></div>
        <div className="absolute bottom-20 left-1/4 w-12 h-12 bg-red-300 rounded-full"></div>
        <div className="absolute bottom-32 right-1/3 w-24 h-24 bg-orange-200 rounded-full"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div>
            {/* Trust Badge */}
            <div className="flex items-center space-x-2 mb-6">
              <div className="flex items-center bg-white rounded-full px-4 py-2 shadow-md">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                ))}
                <span className="ml-2 text-sm font-medium text-gray-700">10,000+ happy customers</span>
              </div>
            </div>

            {/* Main Headline */}
            <h1 className="text-4xl lg:text-6xl font-bold text-gray-900 leading-tight mb-6">
              <span className="text-orange-500">For the Busy You,</span>
              <br />
              <span className="text-gray-800">from the Caring Few</span>
            </h1>

            {/* Subheadline */}
            <p className="text-xl text-gray-600 leading-relaxed mb-8">
              Bringing the warmth of home-cooked food to people who don't have time to cook 
              but still crave healthy, comforting meals. Connect with talented home cooks who 
              prepare meals with love, just like someone at home would.
            </p>

            {/* Value Propositions */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
              <div className="flex items-center space-x-3">
                <div className="bg-green-100 p-2 rounded-full">
                  <Heart className="h-5 w-5 text-green-600" />
                </div>
                <span className="text-gray-700 font-medium">Made with Love</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="bg-blue-100 p-2 rounded-full">
                  <Clock className="h-5 w-5 text-blue-600" />
                </div>
                <span className="text-gray-700 font-medium">Always On Time</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="bg-purple-100 p-2 rounded-full">
                  <Users className="h-5 w-5 text-purple-600" />
                </div>
                <span className="text-gray-700 font-medium">Community Driven</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="bg-orange-100 p-2 rounded-full">
                  <Star className="h-5 w-5 text-orange-600" />
                </div>
                <span className="text-gray-700 font-medium">Quality Assured</span>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 mb-12">
              <button 
                onClick={handleStartSubscription}
                className="bg-orange-500 text-white px-8 py-4 rounded-lg hover:bg-orange-600 transition-all duration-300 transform hover:scale-105 font-semibold flex items-center justify-center group shadow-lg"
              >
                {user && userProfile ? 'Browse Meal Plans' : 'Start Your Subscription'}
                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </button>
              <button 
                onClick={handleViewMenu}
                className="border-2 border-orange-500 text-orange-500 px-8 py-4 rounded-lg hover:bg-orange-500 hover:text-white transition-all duration-300 font-semibold"
              >
                View Sample Menu
              </button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-8">
              <div className="text-center">
                <div className="flex items-center justify-center mb-2">
                  <Users className="h-6 w-6 text-orange-500 mr-2" />
                  <span className="text-2xl font-bold text-gray-900">500+</span>
                </div>
                <p className="text-gray-600 text-sm">Caring Home Cooks</p>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center mb-2">
                  <Clock className="h-6 w-6 text-green-500 mr-2" />
                  <span className="text-2xl font-bold text-gray-900">30min</span>
                </div>
                <p className="text-gray-600 text-sm">Average Delivery</p>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center mb-2">
                  <Star className="h-6 w-6 text-yellow-400 mr-2" />
                  <span className="text-2xl font-bold text-gray-900">4.9</span>
                </div>
                <p className="text-gray-600 text-sm">Customer Rating</p>
              </div>
            </div>
          </div>

          {/* Right Content - Hero Image */}
          <div className="relative">
            <div className="bg-white rounded-2xl shadow-2xl overflow-hidden transform rotate-3 hover:rotate-0 transition-transform duration-500">
              <img 
                src="https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=800" 
                alt="Delicious homemade meal prepared with love"
                className="w-full h-96 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
            </div>
            
            {/* Floating Cards */}
            <div className="absolute -bottom-6 -left-6 bg-white rounded-xl shadow-lg p-4 max-w-xs transform -rotate-3">
              <div className="flex items-center space-x-3">
                <div className="bg-green-100 p-2 rounded-lg">
                  <Heart className="h-5 w-5 text-green-600" />
                </div>
                <div>
                  <p className="font-semibold text-gray-900">Made with Love</p>
                  <p className="text-sm text-gray-600">By caring home cooks</p>
                </div>
              </div>
            </div>

            <div className="absolute -top-6 -right-6 bg-orange-500 text-white rounded-xl shadow-lg p-4 transform rotate-6">
              <div className="text-center">
                <p className="font-bold text-lg">₹99</p>
                <p className="text-sm opacity-90">per day</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;