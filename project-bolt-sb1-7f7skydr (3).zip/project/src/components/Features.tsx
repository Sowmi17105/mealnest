import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Calendar, Users, Truck, CreditCard, Heart, Shield, Clock, Home } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

const Features = () => {
  const navigate = useNavigate();
  const { user } = useAuth();

  const handleStartJourney = () => {
    if (user) {
      navigate('/meal-plans');
    } else {
      navigate('/auth');
    }
  };

  const features = [
    {
      icon: Calendar,
      title: 'Flexible Subscriptions',
      description: 'Choose breakfast, lunch, supper, or all three. Subscribe monthly, quarterly, or yearly for the best value.',
      color: 'bg-blue-100 text-blue-600',
      highlight: 'Daily, Weekly, Monthly'
    },
    {
      icon: Users,
      title: 'Pre-book for Groups',
      description: 'Planning a gathering? Pre-book meals 24 hours in advance for guests, office lunches, or celebrations.',
      color: 'bg-purple-100 text-purple-600',
      highlight: 'Perfect for Events'
    },
    {
      icon: Truck,
      title: 'Delivery Included',
      description: 'No hidden charges. Delivery is included in your meal price, ensuring hot food reaches you on time.',
      color: 'bg-green-100 text-green-600',
      highlight: 'Always Hot & Fresh'
    },
    {
      icon: CreditCard,
      title: 'Simple Payments',
      description: 'Transparent pricing with no surprises. Pay securely online with multiple payment options.',
      color: 'bg-yellow-100 text-yellow-600',
      highlight: 'No Hidden Fees'
    },
    {
      icon: Heart,
      title: 'Made with Love',
      description: 'Every meal is prepared by caring home cooks who put love and attention into each dish.',
      color: 'bg-red-100 text-red-600',
      highlight: 'Home-style Cooking'
    },
    {
      icon: Shield,
      title: 'Quality Assured',
      description: 'All our partner cooks are verified and follow strict hygiene and quality standards.',
      color: 'bg-indigo-100 text-indigo-600',
      highlight: 'Verified Cooks'
    },
    {
      icon: Clock,
      title: 'Perfect Timing',
      description: 'Meals delivered exactly when you need them - morning breakfast, office lunch, or evening supper.',
      color: 'bg-orange-100 text-orange-600',
      highlight: 'Right on Schedule'
    },
    {
      icon: Home,
      title: 'Empowering Women',
      description: 'Supporting homemakers by turning their kitchens into income sources while serving the community.',
      color: 'bg-pink-100 text-pink-600',
      highlight: 'Community Impact'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Why Choose Mealnest?
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            We're not just a food delivery service. We're a community that brings 
            the warmth of home-cooked meals to your busy life while empowering local home cooks.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <div 
              key={index}
              className={`bg-gray-50 rounded-xl p-6 hover:shadow-lg transition-all duration-300 transform hover:-translate-y-2 group`}
            >
              <div className={`${feature.color} w-14 h-14 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                <feature.icon className="h-7 w-7" />
              </div>
              
              <div className="mb-2">
                <span className="text-xs font-semibold text-orange-500 uppercase tracking-wide">
                  {feature.highlight}
                </span>
              </div>
              
              <h3 className="text-lg font-semibold text-gray-900 mb-3">
                {feature.title}
              </h3>
              
              <p className="text-gray-600 leading-relaxed text-sm">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-16">
          <div className="bg-gradient-to-r from-orange-500 to-red-500 rounded-2xl p-8 text-white">
            <h3 className="text-2xl font-bold mb-4">Ready to Experience Home-Cooked Goodness?</h3>
            <p className="text-lg opacity-90 mb-6">Join thousands of satisfied customers who've made Mealnest part of their daily routine.</p>
            <button 
              onClick={handleStartJourney}
              className="bg-white text-orange-500 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
            >
              {user ? 'Browse Meal Plans' : 'Start Your Journey Today'}
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Features;