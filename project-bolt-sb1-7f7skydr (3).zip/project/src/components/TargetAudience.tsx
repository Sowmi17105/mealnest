import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Briefcase, GraduationCap, BookOpen, Heart, Home, Users, Clock, Coffee } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

const TargetAudience = () => {
  const navigate = useNavigate();
  const { user } = useAuth();

  const handleFindYourPlan = () => {
    if (user) {
      navigate('/meal-plans');
    } else {
      navigate('/auth');
    }
  };

  const audiences = [
    {
      icon: Briefcase,
      title: 'Working Professionals',
      description: 'Long hours at the office? Skip the meal prep stress and focus on what you do best. Get nutritious meals delivered right to your workplace.',
      benefits: ['Office delivery', 'Healthy lunch options', 'Time-saving breakfast'],
      image: 'https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=400',
      color: 'bg-blue-50 border-blue-200'
    },
    {
      icon: GraduationCap,
      title: 'Students',
      description: 'Hostel and PG life made easier! Affordable, healthy meals that fuel your studies. No more instant noodles – get real food that nourishes.',
      benefits: ['Budget-friendly pricing', 'Hostel delivery', 'Nutritious & filling'],
      image: 'https://images.pexels.com/photos/3768146/pexels-photo-3768146.jpeg?auto=compress&cs=tinysrgb&w=400',
      color: 'bg-green-50 border-green-200'
    },
    {
      icon: BookOpen,
      title: 'Teachers & Educators',
      description: 'Busy schedules deserve easy meals. Get homemade food delivered between classes and after long teaching days.',
      benefits: ['School-friendly timing', 'Energy-boosting meals', 'Quick delivery'],
      image: 'https://images.pexels.com/photos/3769021/pexels-photo-3769021.jpeg?auto=compress&cs=tinysrgb&w=400',
      color: 'bg-purple-50 border-purple-200'
    },
    {
      icon: Heart,
      title: 'Elderly',
      description: 'Enjoy the comfort of homemade meals without the cooking effort. Perfect for those living independently who want nutritious, easy-to-eat food.',
      benefits: ['Easy to digest', 'Nutritionally balanced', 'Regular meal schedule'],
      image: 'https://images.pexels.com/photos/3768916/pexels-photo-3768916.jpeg?auto=compress&cs=tinysrgb&w=400',
      color: 'bg-orange-50 border-orange-200'
    },
    {
      icon: Home,
      title: 'Busy Families',
      description: 'One less thing to worry about! Get family-sized portions of homemade food for everyone to enjoy. More time for what matters.',
      benefits: ['Family portions', 'Kid-friendly options', 'Quality family time'],
      image: 'https://images.pexels.com/photos/4259140/pexels-photo-4259140.jpeg?auto=compress&cs=tinysrgb&w=400',
      color: 'bg-pink-50 border-pink-200'
    },
    {
      icon: Users,
      title: 'Group Events',
      description: 'Planning office lunches, birthday parties, or small gatherings? Pre-book meals 24 hours in advance for any group size.',
      benefits: ['Bulk ordering', '24hr advance booking', 'Event catering'],
      image: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=400',
      color: 'bg-yellow-50 border-yellow-200'
    }
  ];

  return (
    <section id="for-whom" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Who We Serve
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Mealnest is designed for anyone who values good food but doesn't have the time to cook. 
            Here's how we make life easier for different people in our community.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {audiences.map((audience, index) => (
            <div 
              key={index}
              className={`bg-white border-2 ${audience.color} rounded-xl overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 group`}
            >
              <div className="h-48 overflow-hidden relative">
                <img 
                  src={audience.image} 
                  alt={audience.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
              </div>
              
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <div className="bg-orange-100 p-3 rounded-lg mr-3">
                    <audience.icon className="h-6 w-6 text-orange-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900">
                    {audience.title}
                  </h3>
                </div>
                
                <p className="text-gray-600 mb-4 leading-relaxed">
                  {audience.description}
                </p>
                
                <div className="space-y-2">
                  {audience.benefits.map((benefit, benefitIndex) => (
                    <div key={benefitIndex} className="flex items-center text-sm text-gray-700">
                      <div className="w-2 h-2 bg-green-400 rounded-full mr-3 flex-shrink-0"></div>
                      <span>{benefit}</span>
                    </div>
                  ))}
                </div>

                <button 
                  onClick={handleFindYourPlan}
                  className="mt-4 w-full bg-orange-500 text-white py-2 px-4 rounded-lg hover:bg-orange-600 transition-colors font-medium"
                >
                  {user ? 'Browse Plans' : 'Find Your Plan'}
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Community Impact Section */}
        <div className="mt-16 bg-gradient-to-r from-orange-500 to-red-500 rounded-2xl p-8 text-white text-center">
          <div className="max-w-3xl mx-auto">
            <h3 className="text-2xl font-bold mb-4">Building a Community of Care</h3>
            <p className="text-lg opacity-90 mb-6">
              Every meal you order supports local homemakers, empowers women entrepreneurs, 
              and strengthens our community. Together, we're creating a healthier, more connected world.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
              <div className="text-center">
                <div className="text-3xl font-bold">500+</div>
                <div className="text-sm opacity-90">Women Empowered</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold">10K+</div>
                <div className="text-sm opacity-90">Meals Served Daily</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold">50+</div>
                <div className="text-sm opacity-90">Cities Served</div>
              </div>
            </div>
          </div>
        </div>

        <div className="text-center mt-12">
          <p className="text-lg text-gray-600 mb-6">
            See yourself in one of these groups? We've got the perfect meal plan for you.
          </p>
          <button 
            onClick={handleFindYourPlan}
            className="bg-orange-500 text-white px-8 py-4 rounded-lg hover:bg-orange-600 transition-colors font-semibold text-lg shadow-lg transform hover:scale-105"
          >
            {user ? 'Browse Perfect Plans' : 'Find Your Perfect Plan'}
          </button>
        </div>
      </div>
    </section>
  );
};

export default TargetAudience;