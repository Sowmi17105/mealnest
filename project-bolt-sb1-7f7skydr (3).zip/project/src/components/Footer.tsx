import React from 'react';
import { ChefHat, Mail, Phone, MapPin, Facebook, Twitter, Instagram, Heart } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand Section */}
          <div className="md:col-span-1">
            <div className="flex items-center space-x-2 mb-6">
              <div className="bg-orange-500 p-2 rounded-lg">
                <ChefHat className="h-6 w-6 text-white" />
              </div>
              <div>
                <h3 className="text-2xl font-bold">Mealnest</h3>
                <p className="text-sm text-gray-400">For the Busy You, from the Caring Few</p>
              </div>
            </div>
            <p className="text-gray-400 leading-relaxed mb-6">
              Connecting busy people with caring home cooks, one meal at a time. 
              Experience the warmth of homemade food delivered fresh to your door.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="bg-gray-800 p-2 rounded-lg hover:bg-orange-500 transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="bg-gray-800 p-2 rounded-lg hover:bg-orange-500 transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="bg-gray-800 p-2 rounded-lg hover:bg-orange-500 transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Quick Links</h4>
            <ul className="space-y-3">
              <li><a href="#" className="text-gray-400 hover:text-orange-500 transition-colors">How It Works</a></li>
              <li><a href="#" className="text-gray-400 hover:text-orange-500 transition-colors">Meal Plans</a></li>
              <li><a href="#" className="text-gray-400 hover:text-orange-500 transition-colors">Sample Menu</a></li>
              <li><a href="#" className="text-gray-400 hover:text-orange-500 transition-colors">Pricing</a></li>
              <li><a href="#" className="text-gray-400 hover:text-orange-500 transition-colors">Free Trial</a></li>
            </ul>
          </div>

          {/* For Cooks */}
          <div>
            <h4 className="text-lg font-semibold mb-6">For Home Cooks</h4>
            <ul className="space-y-3">
              <li><a href="#" className="text-gray-400 hover:text-orange-500 transition-colors">Join as Cook</a></li>
              <li><a href="#" className="text-gray-400 hover:text-orange-500 transition-colors">Cook Guidelines</a></li>
              <li><a href="#" className="text-gray-400 hover:text-orange-500 transition-colors">Earnings</a></li>
              <li><a href="#" className="text-gray-400 hover:text-orange-500 transition-colors">Success Stories</a></li>
              <li><a href="#" className="text-gray-400 hover:text-orange-500 transition-colors">Support</a></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Contact Us</h4>
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <Phone className="h-5 w-5 text-orange-500" />
                <span className="text-gray-400">+91 98765 43210</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="h-5 w-5 text-orange-500" />
                <span className="text-gray-400">hello@mealnest.com</span>
              </div>
              <div className="flex items-start space-x-3">
                <MapPin className="h-5 w-5 text-orange-500 mt-1" />
                <span className="text-gray-400">
                  123 Food Street<br />
                  Bangalore, Karnataka 560001
                </span>
              </div>
            </div>

            <div className="mt-6">
              <h5 className="font-semibold mb-3">Subscribe to Updates</h5>
              <div className="flex">
                <input 
                  type="email" 
                  placeholder="Your email"
                  className="flex-1 px-4 py-2 bg-gray-800 border border-gray-700 rounded-l-lg focus:outline-none focus:border-orange-500"
                />
                <button className="bg-orange-500 px-4 py-2 rounded-r-lg hover:bg-orange-600 transition-colors">
                  Subscribe
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-gray-800 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-4 mb-4 md:mb-0">
              <p className="text-gray-400">
                © 2025 Mealnest. All rights reserved.
              </p>
              <div className="flex items-center space-x-1 text-orange-500">
                <span className="text-sm">Made with</span>
                <Heart className="h-4 w-4 fill-current" />
                <span className="text-sm">for busy food lovers</span>
              </div>
            </div>
            <div className="flex space-x-6">
              <a href="#" className="text-gray-400 hover:text-orange-500 transition-colors text-sm">
                Privacy Policy
              </a>
              <a href="#" className="text-gray-400 hover:text-orange-500 transition-colors text-sm">
                Terms of Service
              </a>
              <a href="#" className="text-gray-400 hover:text-orange-500 transition-colors text-sm">
                Refund Policy
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;