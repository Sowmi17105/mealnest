import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Menu, X, ChefHat, Phone, Mail, User, LogOut } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user, userProfile, signOut } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const handleSubscribeNow = () => {
    console.log('Subscribe Now clicked', { user, userProfile });
    
    if (user && userProfile) {
      // User is authenticated, redirect to appropriate dashboard or meal plans
      if (userProfile.user_type === 'customer') {
        navigate('/meal-plans');
      } else {
        navigate('/homemaker-dashboard');
      }
    } else {
      // User not authenticated, redirect to auth page
      navigate('/auth');
    }
    setIsMenuOpen(false);
  };

  const handleSignOut = async () => {
    try {
      await signOut();
      navigate('/');
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  const handleDashboardNavigation = () => {
    if (user && userProfile) {
      const dashboardPath = userProfile.user_type === 'customer' 
        ? '/customer-dashboard' 
        : '/homemaker-dashboard';
      navigate(dashboardPath);
    }
    setIsMenuOpen(false);
  };

  const handleNavigation = (path: string, sectionId?: string) => {
    setIsMenuOpen(false);
    
    if (path === '/' && sectionId) {
      // If we're navigating to a section on the landing page
      if (location.pathname === '/') {
        // Already on landing page, just scroll to section
        const element = document.getElementById(sectionId);
        if (element) {
          element.scrollIntoView({ behavior: 'smooth' });
        }
      } else {
        // Navigate to landing page first, then scroll to section
        navigate('/');
        setTimeout(() => {
          const element = document.getElementById(sectionId);
          if (element) {
            element.scrollIntoView({ behavior: 'smooth' });
          }
        }, 100);
      }
    } else {
      // Direct navigation to other pages
      navigate(path);
    }
  };

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          {/* Logo */}
          <div 
            className="flex items-center space-x-2 cursor-pointer"
            onClick={() => navigate('/')}
          >
            <div className="bg-orange-500 p-2 rounded-lg">
              <ChefHat className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Mealnest</h1>
              <p className="text-xs text-gray-600 leading-tight">For the Busy You, from the Caring Few</p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <button 
              onClick={() => handleNavigation('/', 'how-it-works')}
              className="text-gray-700 hover:text-orange-500 transition-colors font-medium"
            >
              How it Works
            </button>
            <button 
              onClick={() => handleNavigation('/meal-plans')}
              className="text-gray-700 hover:text-orange-500 transition-colors font-medium"
            >
              Meal Plans
            </button>
            <button 
              onClick={() => handleNavigation('/chefs')}
              className="text-gray-700 hover:text-orange-500 transition-colors font-medium"
            >
              Our Chefs
            </button>
            <button 
              onClick={() => handleNavigation('/', 'for-whom')}
              className="text-gray-700 hover:text-orange-500 transition-colors font-medium"
            >
              Who We Serve
            </button>
            <button 
              onClick={() => handleNavigation('/contact')}
              className="text-gray-700 hover:text-orange-500 transition-colors font-medium"
            >
              Contact
            </button>
            
            {user && userProfile ? (
              <div className="flex items-center space-x-4">
                <button
                  onClick={handleDashboardNavigation}
                  className="flex items-center space-x-2 text-gray-700 hover:text-orange-500 transition-colors"
                >
                  <User className="h-4 w-4" />
                  <span>Hi, {userProfile?.full_name?.split(' ')[0]}</span>
                </button>
                <button
                  onClick={handleSubscribeNow}
                  className="bg-orange-500 text-white px-6 py-2 rounded-lg hover:bg-orange-600 transition-colors font-medium"
                >
                  {userProfile.user_type === 'customer' ? 'Browse Plans' : 'Dashboard'}
                </button>
                <button
                  onClick={handleSignOut}
                  className="text-gray-600 hover:text-red-600 transition-colors"
                >
                  <LogOut className="h-5 w-5" />
                </button>
              </div>
            ) : (
              <button 
                onClick={handleSubscribeNow}
                className="bg-orange-500 text-white px-6 py-2 rounded-lg hover:bg-orange-600 transition-colors font-medium"
              >
                Subscribe Now
              </button>
            )}
          </nav>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden pb-4">
            <nav className="flex flex-col space-y-4">
              <button 
                onClick={() => handleNavigation('/', 'how-it-works')}
                className="text-gray-700 hover:text-orange-500 transition-colors font-medium text-left"
              >
                How it Works
              </button>
              <button 
                onClick={() => handleNavigation('/meal-plans')}
                className="text-gray-700 hover:text-orange-500 transition-colors font-medium text-left"
              >
                Meal Plans
              </button>
              <button 
                onClick={() => handleNavigation('/chefs')}
                className="text-gray-700 hover:text-orange-500 transition-colors font-medium text-left"
              >
                Our Chefs
              </button>
              <button 
                onClick={() => handleNavigation('/', 'for-whom')}
                className="text-gray-700 hover:text-orange-500 transition-colors font-medium text-left"
              >
                Who We Serve
              </button>
              <button 
                onClick={() => handleNavigation('/contact')}
                className="text-gray-700 hover:text-orange-500 transition-colors font-medium text-left"
              >
                Contact
              </button>
              
              {user && userProfile ? (
                <div className="space-y-2">
                  <button
                    onClick={handleDashboardNavigation}
                    className="flex items-center space-x-2 text-gray-700 hover:text-orange-500 transition-colors"
                  >
                    <User className="h-4 w-4" />
                    <span>Hi, {userProfile?.full_name?.split(' ')[0]}</span>
                  </button>
                  <button
                    onClick={handleSubscribeNow}
                    className="bg-orange-500 text-white px-6 py-2 rounded-lg hover:bg-orange-600 transition-colors font-medium self-start"
                  >
                    {userProfile.user_type === 'customer' ? 'Browse Plans' : 'Dashboard'}
                  </button>
                  <button
                    onClick={handleSignOut}
                    className="text-gray-600 hover:text-red-600 transition-colors self-start flex items-center"
                  >
                    <LogOut className="h-4 w-4 mr-2" />
                    Sign Out
                  </button>
                </div>
              ) : (
                <button 
                  onClick={handleSubscribeNow}
                  className="bg-orange-500 text-white px-6 py-2 rounded-lg hover:bg-orange-600 transition-colors font-medium self-start"
                >
                  Subscribe Now
                </button>
              )}
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;