import React, { useState } from 'react';
import { X, Calendar, Clock, MapPin, CreditCard } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';

interface OrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  mealPlan: any;
}

const OrderModal: React.FC<OrderModalProps> = ({ isOpen, onClose, mealPlan }) => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [orderData, setOrderData] = useState({
    startDate: '',
    subscriptionType: 'monthly' as 'monthly' | 'quarterly' | 'yearly',
    deliveryAddress: '',
    specialInstructions: '',
  });

  const subscriptionOptions = {
    monthly: { duration: 30, discount: 0, label: 'Monthly' },
    quarterly: { duration: 90, discount: 0.12, label: 'Quarterly (12% off)' },
    yearly: { duration: 365, discount: 0.20, label: 'Yearly (20% off)' }
  };

  const calculateTotal = () => {
    const option = subscriptionOptions[orderData.subscriptionType];
    const basePrice = mealPlan.price_per_day * option.duration;
    const discount = basePrice * option.discount;
    return basePrice - discount;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    setLoading(true);
    try {
      const startDate = new Date(orderData.startDate);
      const endDate = new Date(startDate);
      endDate.setDate(endDate.getDate() + subscriptionOptions[orderData.subscriptionType].duration);

      const { error } = await supabase
        .from('subscriptions')
        .insert({
          customer_id: user.id,
          meal_plan_id: mealPlan.id,
          start_date: startDate.toISOString().split('T')[0],
          end_date: endDate.toISOString().split('T')[0],
          subscription_type: orderData.subscriptionType,
          status: 'active'
        });

      if (error) throw error;

      alert('Order placed successfully! You will receive a confirmation email shortly.');
      onClose();
    } catch (error: any) {
      alert('Error placing order: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center p-6 border-b">
          <h2 className="text-2xl font-bold text-gray-900">Place Your Order</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="h-6 w-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Meal Plan Summary */}
          <div className="bg-gray-50 rounded-lg p-4">
            <h3 className="font-semibold text-gray-900 mb-2">{mealPlan.name}</h3>
            <p className="text-gray-600 mb-2">{mealPlan.description}</p>
            <div className="flex items-center text-sm text-gray-500">
              <span className="capitalize">{mealPlan.meal_type.replace('_', ' ')}</span>
              <span className="mx-2">•</span>
              <span>₹{mealPlan.price_per_day}/day</span>
            </div>
          </div>

          {/* Start Date */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Calendar className="inline h-4 w-4 mr-1" />
              Start Date
            </label>
            <input
              type="date"
              required
              min={new Date().toISOString().split('T')[0]}
              value={orderData.startDate}
              onChange={(e) => setOrderData({ ...orderData, startDate: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
            />
          </div>

          {/* Subscription Type */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Clock className="inline h-4 w-4 mr-1" />
              Subscription Duration
            </label>
            <div className="space-y-3">
              {Object.entries(subscriptionOptions).map(([key, option]) => (
                <label key={key} className="flex items-center">
                  <input
                    type="radio"
                    name="subscriptionType"
                    value={key}
                    checked={orderData.subscriptionType === key}
                    onChange={(e) => setOrderData({ ...orderData, subscriptionType: e.target.value as any })}
                    className="mr-3"
                  />
                  <span className="flex-1">{option.label}</span>
                  <span className="font-semibold">
                    ₹{(mealPlan.price_per_day * option.duration * (1 - option.discount)).toFixed(0)}
                  </span>
                </label>
              ))}
            </div>
          </div>

          {/* Delivery Address */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <MapPin className="inline h-4 w-4 mr-1" />
              Delivery Address
            </label>
            <textarea
              required
              rows={3}
              value={orderData.deliveryAddress}
              onChange={(e) => setOrderData({ ...orderData, deliveryAddress: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
              placeholder="Enter your complete delivery address"
            />
          </div>

          {/* Special Instructions */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Special Instructions (Optional)
            </label>
            <textarea
              rows={2}
              value={orderData.specialInstructions}
              onChange={(e) => setOrderData({ ...orderData, specialInstructions: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
              placeholder="Any dietary restrictions or special requests"
            />
          </div>

          {/* Order Summary */}
          <div className="bg-orange-50 rounded-lg p-4">
            <h4 className="font-semibold text-gray-900 mb-2">Order Summary</h4>
            <div className="space-y-1 text-sm">
              <div className="flex justify-between">
                <span>Duration:</span>
                <span>{subscriptionOptions[orderData.subscriptionType].duration} days</span>
              </div>
              <div className="flex justify-between">
                <span>Daily Rate:</span>
                <span>₹{mealPlan.price_per_day}</span>
              </div>
              {subscriptionOptions[orderData.subscriptionType].discount > 0 && (
                <div className="flex justify-between text-green-600">
                  <span>Discount:</span>
                  <span>-₹{(mealPlan.price_per_day * subscriptionOptions[orderData.subscriptionType].duration * subscriptionOptions[orderData.subscriptionType].discount).toFixed(0)}</span>
                </div>
              )}
              <div className="flex justify-between font-semibold text-lg border-t pt-2">
                <span>Total:</span>
                <span>₹{calculateTotal().toFixed(0)}</span>
              </div>
            </div>
          </div>

          {/* Submit Button */}
          <div className="flex space-x-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex-1 bg-orange-500 text-white px-6 py-3 rounded-lg hover:bg-orange-600 transition-colors font-semibold flex items-center justify-center disabled:opacity-50"
            >
              {loading ? (
                'Processing...'
              ) : (
                <>
                  <CreditCard className="h-5 w-5 mr-2" />
                  Place Order
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default OrderModal;